# WILDGUARD AI — COMPLETE WIRING DIAGRAMS & ESP32 GPIO PINOUT REFERENCE

## 1. Electrical Safety Golden Rules (Mandatory for Beginners)
1. **3.3V GPIO Logic Limit**: The **ESP32 DevKit V1** (`ESP-WROOM-32`) operates strictly at **3.3V CMOS logic** on all GPIO pins (`ViH = 2.47V`, `ViL = 0.82V`, absolute maximum `3.6V`). Never connect a **5.0V** output signal directly to any ESP32 GPIO pin.
2. **HC-SR04 5V ECHO Voltage Divider (`1kΩ + 2kΩ`)**: Because the indoor **HC-SR04** ultrasonic sensor is powered from `5.0V` (`VIN`), its `ECHO` pin outputs **`5.0V HIGH`**. Passing `ECHO` through a **`1kΩ` top resistor (`R1`)** and **`2kΩ` bottom resistor (`R2`)** to Common Ground steps the signal down to:
   $$V_{\text{GPIO18}} = 5.00\text{V} \times \frac{2000\,\Omega}{1000\,\Omega + 2000\,\Omega} = 3.33\text{V}$$
3. **SX1278 LoRa Module `3.3V` Supply Rule**: The **Semtech SX1278 / Ra-02 LoRa** transceiver must be powered strictly from the **`3.3V` regulated rail** (`1.8V–3.7V max`). Never connect LoRa `VCC` to `5V` or raw `7.4V` battery voltage.
4. **LED Current-Limiting Resistors (`220Ω`)**: Every LED (`Green GPIO 2`, `Red GPIO 19`, `Blue GPIO 21`) uses a **`220Ω` series resistor** (`Red-Red-Brown-Gold`) to limit current to `5.45mA` (Green), `5.91mA` (Red), and `1.36mA` (Blue), well below the ESP32's `12mA` per-pin recommendation.
5. **2N2222 NPN Transistor Buzzer Driver (`GPIO 23`)**: A 5V active buzzer draws `30–45mA`. Driving it through a **2N2222 NPN transistor** with a **`1kΩ` base resistor** keeps `GPIO 23` base current at a safe **`2.60mA`**.
6. **Common Ground (`0V`)**: All power supplies (`USB 5V`, `18650 Battery`, `5V/3.3V Regulator`, `Solar Panel`), sensors, dividers, LEDs, buzzer, and LoRa radio must share the **Breadboard Blue Common Ground Rail (`GND`)**.

## 2. Master ESP32 DevKit V1 (30-Pin) Pinout & Connection Table

| Component | Component Pin | Connects To | Wire Color & Type | Voltage / Current | Engineering Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **ESP32 Power** | `VIN (5V)` | Breadboard `+5V` Red Rail | Red (`M-M`) | `5.00V DC` | Distributes 5V power to sensors & buzzer |
| **ESP32 Ground** | `GND` | Breadboard `GND` Blue Rail | Black (`M-M`) | `0.00V Ref` | Establishes Common Ground across circuit |
| **ESP32 3.3V** | `3V3` | Breadboard `+3.3V` Rail / LoRa | Emerald (`M-M`) | `3.30V DC` | Regulated 3.3V supply for SX1278 LoRa |
| **HC-SR04 Sensor** | `VCC` | Breadboard `+5V` Red Rail | Red (`M-F`) | `5.00V @ 15mA` | Powers 40kHz ultrasonic transducer |
| **HC-SR04 Sensor** | `TRIG` | `ESP32 GPIO 5` | Cyan (`M-F`) | `3.3V 10µs Pulse` | Triggers ultrasonic acoustic burst |
| **HC-SR04 Sensor** | `ECHO (5V Out)` | `1kΩ Resistor` (`RES1K_IN`) | Yellow (`M-F`) | `5.00V Raw` | Feeds 5V echo pulse into voltage divider |
| **1kΩ / 2kΩ Divider** | `DIV_JUNCTION` | `ESP32 GPIO 18` | Green (`M-M`) | `3.33V Safe` | Delivers stepped-down echo pulse to ESP32 |
| **2kΩ Resistor** | `RES2K_GND` | Breadboard `GND` Blue Rail | Black (`M-M`) | `0.00V Ref` | Anchors divider bottom leg to ground |
| **TF02-Pro LiDAR** | `LIDAR_TX` | `ESP32 GPIO 16 (UART2 RX)` | Cyan (`M-F`) | `3.3V LVTTL` | 0.1–40m outdoor laser Time-of-Flight data |
| **HC-SR501 PIR** | `PIR_OUT` | `ESP32 GPIO 27` | Yellow (`M-F`) | `3.3V Digital` | Passive IR motion wake-up trigger |
| **Green Safe LED** | `Anode (+)` | `ESP32 GPIO 2` via `220Ω` | Green (`M-M`) | `2.1V @ 5.45mA` | ON during normal safe perimeter monitoring |
| **Red Warning LED** | `Anode (+)` | `ESP32 GPIO 19` via `220Ω` | Red/Rose (`M-M`) | `2.0V @ 5.91mA` | ON during Zone 2/3 wildlife warning |
| **Blue IoT TX LED** | `Anode (+)` | `ESP32 GPIO 21` via `220Ω` | Sky Blue (`M-M`) | `3.0V @ 1.36mA` | Pulses during LoRa / IoT packet transmission |
| **2N2222 NPN Driver** | `Base (Pin 2)` | `ESP32 GPIO 23` via `1kΩ` | Amber (`M-M`) | `0.7V @ 2.60mA` | Switches buzzer load safely from GPIO 23 |
| **Active Buzzer** | `BUZ_IO (-)` | `2N2222 Collector (Pin 3)` | Amber (`M-F`) | `5.0V @ 30.0mA` | Acoustic wildlife deterrent (30s max cutoff) |
| **SX1278 LoRa** | `VCC / SPI / ANT` | `3.3V` + `ESP32 SPI` + `Whip Ant` | Purple (`M-F`) | `3.30V @ 120mA` | Long-range 433/868MHz farm-to-gateway link |
| **Power System** | `Solar + 18650` | `LM2596/AMS1117 Regulator` | Red/Black (`M-M`) | `7.4V → 5V & 3.3V` | Off-grid solar battery regulation |
