// ============================================================================
// WILDGUARD AI 3.0 — MODULE 1: SENSORS, CLASS MAPPING, PERSISTENT STORAGE & IOT
// File: src/js/01_sensors_and_storage.js
// ============================================================================

// 1. MULTI-SENSOR ENGINEERING CATALOG (Fixes the HC-SR04 15m flaw!)
const SENSOR_CATALOG_3 = {
  TF02_PRO_LIDAR: {
    id: 'TF02_PRO_LIDAR',
    name: 'Benewake TF02-Pro IP65 Outdoor ToF LiDAR',
    shortName: 'TF02-Pro LiDAR (40m Outdoor)',
    minRangeM: 0.10,
    maxRangeM: 40.00,
    defaultWarnM: 15.0,
    defaultCritM: 5.0,
    accuracyCm: 5.0,
    interfaceDesc: 'UART2 (GPIO 16 RX / GPIO 17 TX, 3.3V Logic Safe)',
    outdoorRated: true,
    costTier: 'Medium ($85–$110)',
    envLimitations: 'Heavy mud directly blocking optical window or extreme fog (>95% opacity) can reduce max range from 40m to ~22m.',
    recommendedUse: 'Primary outdoor agricultural perimeter & crop row protection (supports 15m Warning & 5m Critical thresholds).'
  },
  TF_LUNA_LIDAR: {
    id: 'TF_LUNA_LIDAR',
    name: 'Benewake TF-Luna Mid-Range ToF LiDAR',
    shortName: 'TF-Luna LiDAR (8m Gate/Fence)',
    minRangeM: 0.20,
    maxRangeM: 8.00,
    defaultWarnM: 6.5,
    defaultCritM: 3.0,
    accuracyCm: 2.0,
    interfaceDesc: 'UART2 / I2C (3.3V Logic Safe)',
    outdoorRated: false,
    costTier: 'Low-Medium ($22–$28)',
    envLimitations: '8.0m maximum range; requires IP65 acrylic enclosure window for outdoor weather protection.',
    recommendedUse: 'Orchard gates, narrow wildlife trails, or medium-scale demonstration setups up to 8 metres.'
  },
  HLK_LD2410_RADAR: {
    id: 'HLK_LD2410_RADAR',
    name: 'HLK-LD2410 24GHz FMCW Millimeter-Wave Radar',
    shortName: 'LD2410 24GHz Radar (6m All-Weather)',
    minRangeM: 0.75,
    maxRangeM: 6.00,
    defaultWarnM: 5.0,
    defaultCritM: 2.5,
    accuracyCm: 15.0,
    interfaceDesc: 'UART2 (3.3V Logic Safe, 256000 bps)',
    outdoorRated: true,
    costTier: 'Low ($5–$9)',
    envLimitations: '6.0m max range; wider ±60° beam cone. Completely unaffected by heavy rain, dense fog, darkness, dust, or temperature.',
    recommendedUse: 'All-weather close-perimeter radar fusion in heavy monsoon rain or dense fog.'
  },
  JSN_SR04T_ULTRASONIC: {
    id: 'JSN_SR04T_ULTRASONIC',
    name: 'JSN-SR04T Waterproof Ultrasonic Sensor',
    shortName: 'JSN-SR04T Waterproof (4.5m)',
    minRangeM: 0.25,
    maxRangeM: 4.50,
    defaultWarnM: 3.5,
    defaultCritM: 1.5,
    accuracyCm: 1.5,
    interfaceDesc: 'TRIG (GPIO 5) / ECHO (GPIO 18 via 1kΩ+2kΩ 5V→3.3V Divider)',
    outdoorRated: true,
    costTier: 'Low ($8–$12)',
    envLimitations: '4.5m max range; 25cm blind zone; soft animal fur absorbs ultrasonic waves beyond 4.0m.',
    recommendedUse: 'Low-cost weatherproof short-range boundary or cattle/boar fence gap sensor.'
  },
  HC_SR04_LAB: {
    id: 'HC_SR04_LAB',
    name: 'HC-SR04 Ultrasonic Sensor (Indoor Lab Demo Only)',
    shortName: 'HC-SR04 (Lab Only: Max 4.0m!)',
    minRangeM: 0.02,
    maxRangeM: 4.00,
    defaultWarnM: 2.5,
    defaultCritM: 1.0,
    accuracyCm: 0.3,
    interfaceDesc: 'TRIG (GPIO 5) / ECHO (GPIO 18 via 1kΩ+2kΩ 5V→3.3V Divider)',
    outdoorRated: false,
    costTier: 'Ultra-Low ($1.50–$3)',
    envLimitations: 'STRICTLY 0.02m–4.00m indoor tabletop range! Exposed paper transducers fail in rain/humidity. Cannot measure 15m.',
    recommendedUse: 'Classroom/hackathon tabletop breadboard demonstration ONLY (0.02m to 4.00m).'
  }
};

// Validate a distance reading against the installed physical sensor profile
function validateSensorMeasurement3(sensorId, rawDistM, weatherCondition) {
  const spec = SENSOR_CATALOG_3[sensorId] || SENSOR_CATALOG_3.TF02_PRO_LIDAR;
  if (rawDistM === null || rawDistM === undefined || isNaN(rawDistM) || rawDistM < 0) {
    return { valid: false, status: 'INVALID_NO_ECHO', measuredM: null,measuredCm: null, spec };
  }

  // Apply realistic environmental degradation to effective max range
  let effectiveMaxM = spec.maxRangeM;
  if (weatherCondition === 'HEAVY_RAIN' && sensorId === 'HC_SR04_LAB') {
    return { valid: false, status: 'TRANSDUCER_WET_FAULT (INDOOR SENSOR IN RAIN)', measuredM: null, measuredCm: null, spec };
  }
  if (weatherCondition === 'DENSE_FOG' && (sensorId === 'TF02_PRO_LIDAR' || sensorId === 'TF_LUNA_LIDAR')) {
    effectiveMaxM = spec.maxRangeM * 0.65;
  }

  if (rawDistM < spec.minRangeM) {
    return {
      valid: false,
      status: `BLIND_ZONE (<${spec.minRangeM.toFixed(2)}m)`,
      measuredM: null,
      measuredCm: null,
      spec
    };
  }
  if (rawDistM > effectiveMaxM) {
    // Never allow HC-SR04 (or any sensor) to report measurements beyond its physical max range!
    return {
      valid: false,
      status: `OUT_OF_RANGE (>${effectiveMaxM.toFixed(1)}m MAX FOR ${spec.id})`,
      measuredM: null,
      measuredCm: null,
      spec
    };
  }

  return {
    valid: true,
    status: 'VALID_MEASUREMENT',
    measuredM: rawDistM,
    measuredCm: rawDistM * 100.0,
    spec
  };
}

// 2. STRICT WILDLIFE CLASSIFICATION & ANTI-PROXY MAPPING ENGINE
const STRICT_CLASS_MAP_3 = {
  elephant: 'elephant',
  asian_elephant: 'elephant',
  african_elephant: 'elephant',
  wild_boar: 'boar',
  'wild boar': 'boar',
  boar: 'boar',
  sus_scrofa: 'boar',
  deer: 'deer',
  spotted_deer: 'deer',
  sambar: 'deer',
  chital: 'deer',
  monkey: 'monkey',
  macaque: 'monkey',
  rhesus_macaque: 'monkey',
  langur: 'monkey',
  person: 'human',
  human: 'human',
  farmer: 'human'
};

// Explicitly forbidden false proxy classes (never map dog->monkey, sheep->deer, bear->boar!)
const FORBIDDEN_PROXY_SPECIES_3 = new Set([
  'dog', 'sheep', 'bear', 'cow', 'cattle', 'cat', 'horse', 'bird', 'goat', 'zebra', 'giraffe', 'car', 'truck'
]);

function classifyDetectedLabel3(rawLabel) {
  if (!rawLabel || rawLabel === 'none') {
    return { mapped: 'none', category: 'NONE', isTargetWildlife: false, isHuman: false, isUnsupported: false };
  }
  const clean = String(rawLabel).trim().toLowerCase();
  if (FORBIDDEN_PROXY_SPECIES_3.has(clean)) {
    return {
      mapped: 'unsupported',
      rawLabel: clean,
      category: 'UNSUPPORTED / NON-TARGET SPECIES',
      isTargetWildlife: false,
      isHuman: false,
      isUnsupported: true,
      reason: `"${clean}" is a non-target species. False proxy mapping is disabled; wildlife alarm suppressed.`
    };
  }
  const mapped = STRICT_CLASS_MAP_3[clean];
  if (!mapped) {
    return {
      mapped: 'unsupported',
      rawLabel: clean,
      category: 'UNSUPPORTED CLASS',
      isTargetWildlife: false,
      isHuman: false,
      isUnsupported: true,
      reason: `Class "${clean}" is not in the supported wildlife model mapping.`
    };
  }
  if (mapped === 'human') {
    return {
      mapped: 'human',
      rawLabel: clean,
      category: 'HUMAN (SAFETY SILENT STATE)',
      isTargetWildlife: false,
      isHuman: true,
      isUnsupported: false,
      reason: 'Human detected: wildlife alarm and deterrents strictly suppressed.'
    };
  }
  return {
    mapped,
    rawLabel: clean,
    category: 'TARGET WILDLIFE',
    isTargetWildlife: true,
    isHuman: false,
    isUnsupported: false,
    reason: 'Supported target crop-raiding wildlife species.'
  };
}

// 3. PERSISTENT STORAGE MANAGER (LocalStorage + CSV & Printable PDF Export)
const WG3_STORAGE_KEY = 'WILDGUARD_AI_V3_PERSISTENT_STATE';

const WildGuardStorage = {
  loadState() {
    try {
      const raw = localStorage.getItem(WG3_STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  saveState(stateObj) {
    try {
      const payload = {
        savedAt: new Date().toISOString(),
        uiMode: stateObj.uiMode || 'BEGINNER',
        wizardCompleted: Boolean(stateObj.wizardCompleted),
        lowPerfMode: Boolean(stateObj.lowPerfMode),
        installedSensorId: stateObj.installedSensorId || 'TF02_PRO_LIDAR',
        warningDistM: stateObj.warningDistM || 15.0,
        criticalDistM: stateObj.criticalDistM || 5.0,
        aiConfThreshold: stateObj.aiConfThreshold || 0.70,
        aiConfirmFramesReq: stateObj.aiConfirmFramesReq || 4,
        iotConfig: stateObj.iotConfig || {
          provider: 'WEBHOOK',
          endpointUrl: '',
          farmerPhone: '',
          cooldownSec: 15
        },
        eventLogs: (stateObj.eventLogs || []).slice(0, 120),
        phoneAlerts: (stateObj.phoneAlerts || []).slice(0, 80),
        iotQueueItems: (stateObj.iotQueueItems || []).slice(0, 50),
        testResults: stateObj.testResults || {}
      };
      localStorage.setItem(WG3_STORAGE_KEY, JSON.stringify(payload));
      return true;
    } catch (e) {
      return false;
    }
  },

  clearAll() {
    try {
      localStorage.removeItem(WG3_STORAGE_KEY);
    } catch (e) {}
  },

  exportEventsToCSV(eventLogs) {
    const headers = ['Time', 'Mode / Source', 'Detected Object', 'Sensor', 'Distance (m)', 'Distance (cm)', 'System State', 'Action / Outcome', 'Severity'];
    const rows = (eventLogs || []).map(e => [
      e.time || '',
      e.source || '',
      e.objectClass || '',
      e.sensorId || 'TF02_PRO_LIDAR',
      e.distM || '',
      e.distCm || '',
      e.stateLabel || '',
      (e.actionText || '').replace(/"/g, '""'),
      e.severity || 'INFO'
    ]);
    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `WildGuard_AI_3.0_History_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
};
