// ============================================================================
// WILDGUARD AI 3.0 — MODULE 6: CINEMATIC 3D DIGITAL TWIN, 12-SCENE AUTOMATIC
// PRESENTATION DIRECTOR, 6 VISUAL MODES, LORA MESH & DETAILED OBJECT INSPECTOR
// File: src/js/06_cinematic_presentation_and_visual_modes.js
// ============================================================================

const CINEMATIC_12_SCENES = [
  {
    id: 1,
    title: 'SCENE 1 OF 12 — Complete Farm Overview',
    subtitle: 'High-Altitude Aerial Digital Twin of the Protected Agricultural Estate',
    visualMode: 'CINEMATIC',
    durationSec: 6.5,
    cam: { theta: 0.55, phi: 0.92, radius: 44.0, target: [0, 1.5, 4.0], autoOrbitSpeed: 0.14 },
    narration: 'Welcome to WildGuard AI 3.0. From this aerial overview, you can see the protected crop rows at the center, the forest wildlife corridor to the north, perimeter sensor poles, LoRa communication nodes, and the farmhouse monitoring station.'
  },
  {
    id: 2,
    title: 'SCENE 2 OF 12 — Farm Protection Infrastructure',
    subtitle: 'Perimeter Boundary Fencing, Multi-Pole Sensor Towers & ESP32 Edge Units',
    visualMode: 'ENGINEERING',
    durationSec: 6.5,
    cam: { theta: 0.25, phi: 1.12, radius: 19.5, target: [0, 2.2, 8.5], autoOrbitSpeed: 0.08 },
    narration: 'Zooming into the protection perimeter reveals our multi-layered infrastructure: the central solar-powered AI tower, three perimeter sensor poles, TF02-Pro outdoor LiDAR units, and supervised boundary fencing.'
  },
  {
    id: 3,
    title: 'SCENE 3 OF 12 — Camera Coverage, Overlaps & Blind Spots',
    subtitle: '360° Optical & Thermal Field-of-View Cones with Overlap & Blind-Spot Mapping',
    visualMode: 'ENGINEERING',
    durationSec: 7.0,
    cam: { theta: 0.0, phi: 0.32, radius: 38.0, target: [0, 0.5, 5.0], autoOrbitSpeed: 0.05 },
    narration: 'In this top-down engineering view, translucent cyan cones show each camera’s field of view, emerald zones highlight overlapping dual-camera coverage, and amber markers identify outer forest blind spots.'
  },
  {
    id: 4,
    title: 'SCENE 4 OF 12 — Wildlife Entry from Forest Boundary',
    subtitle: 'Articulated 3D Elephant Entering via the North Forest Corridor (24.5m)',
    visualMode: 'CINEMATIC',
    durationSec: 6.5,
    cam: { theta: 0.35, phi: 1.22, radius: 11.5, target: [0, 1.8, 21.0], autoOrbitSpeed: 0.06 },
    narration: 'A wild elephant emerges from the forest boundary at 24 metres and walks along the approach trail toward the crop rows. All simulation metrics are clearly labeled as SIMULATED.'
  },
  {
    id: 5,
    title: 'SCENE 5 OF 12 — Active Camera Detection Viewpoint',
    subtitle: 'Camera-to-Camera Transition into the Tower Optical Gimbal POV',
    visualMode: 'SURVEILLANCE',
    durationSec: 6.5,
    cam: { theta: 0.02, phi: 1.34, radius: 7.2, target: [0, 2.1, 14.0], autoOrbitSpeed: 0.0 },
    narration: 'Transitioning directly to the active tower camera viewpoint: the pan-tilt gimbal automatically locks onto the approaching animal while the LiDAR sensor measures exact physical distance.'
  },
  {
    id: 6,
    title: 'SCENE 6 OF 12 — AI Recognition & 4-Frame Confirmation',
    subtitle: 'YOLOv8 Bounding Box, Species Classification & False-Positive Rejection',
    visualMode: 'SURVEILLANCE',
    durationSec: 6.5,
    cam: { theta: -0.28, phi: 1.18, radius: 10.5, target: [0, 1.8, 13.5], autoOrbitSpeed: 0.05 },
    narration: 'The AI computer vision module draws a real-time bounding box, classifies the species with confidence percentage, and verifies 4 consecutive frames to reject wind or shadow false alarms.'
  },
  {
    id: 7,
    title: 'SCENE 7 OF 12 — Real-Time Animal Tracking & Warning Zone',
    subtitle: 'Dynamic Wildlife-Following Camera as Animal Crosses the 15m Warning Boundary',
    visualMode: 'CINEMATIC',
    durationSec: 7.0,
    cam: { theta: 0.65, phi: 1.15, radius: 9.5, target: [0, 1.6, 12.0], followTarget: true, autoOrbitSpeed: 0.1 },
    narration: 'Our wildlife-following camera tracks the animal as it enters Zone 2 (≤15m). The ESP32 immediately triggers the pulsed acoustic deterrent and warning strobe to guide the animal safely back toward the forest.'
  },
  {
    id: 8,
    title: 'SCENE 8 OF 12 — Thermal & IR Night-Vision Demonstration',
    subtitle: 'Automatic Cycling Between Visible Light, IR Night Vision & FLIR Thermal Mode',
    visualMode: 'THERMAL',
    durationSec: 7.5,
    cam: { theta: -0.42, phi: 1.12, radius: 13.0, target: [0, 1.6, 11.0], followTarget: true, autoOrbitSpeed: 0.08 },
    narration: 'Most crop raids happen at night or in dense fog. WildGuard AI switches seamlessly between Visible Light, Infrared Night Vision, and Thermal heat-signature imaging where warm-blooded wildlife stands out clearly.'
  },
  {
    id: 9,
    title: 'SCENE 9 OF 12 — LoRa Mesh Field-to-Gateway Communication',
    subtitle: 'Long-Range 868/433 MHz LoRa Packet Transmission from Field Node to Gateway',
    visualMode: 'NETWORK',
    durationSec: 7.0,
    cam: { theta: -0.75, phi: 1.05, radius: 22.0, target: [-4.5, 2.2, -1.5], autoOrbitSpeed: 0.08 },
    narration: 'Watch the glowing LoRa RF telemetry packets travel from the solar-powered field sensor nodes to the Central LoRaWAN Gateway mounted on the farmhouse monitoring station—operating even without cellular internet.'
  },
  {
    id: 10,
    title: 'SCENE 10 OF 12 — System Response, Notifications & Fence Safety',
    subtitle: 'Farmer Smartphone Alert, Persistent Event Log & Boundary Fence Supervision',
    visualMode: 'SURVEILLANCE',
    durationSec: 6.5,
    cam: { theta: -0.95, phi: 1.15, radius: 11.5, target: [-9.0, 1.4, -3.8], autoOrbitSpeed: 0.05 },
    narration: 'At the farmhouse monitoring station, the system logs every event persistently, supervises non-lethal boundary fence integrity, and dispatches verified alerts (or queues them as PENDING when offline) to the farmer’s phone.'
  },
  {
    id: 11,
    title: 'SCENE 11 OF 12 — Complete Integrated System Overview',
    subtitle: 'Synchronized View of AI Vision, Ranging Sensors, LoRa Network & Deterrents',
    visualMode: 'OVERVIEW',
    durationSec: 6.5,
    cam: { theta: 0.42, phi: 0.78, radius: 36.0, target: [0, 1.5, 3.0], autoOrbitSpeed: 0.12 },
    narration: 'Pulling back to the complete system overview shows every subsystem working in harmony: optical & thermal cameras, LiDAR/radar ranging, ESP32 edge intelligence, LoRa mesh networking, and humane crop protection.'
  },
  {
    id: 12,
    title: 'SCENE 12 OF 12 — Final Presentation & Project Outcome',
    subtitle: 'WildGuard AI 3.0 Architecture Summary — Ready for Live Jury Q&A & Object Inspection',
    visualMode: 'CINEMATIC',
    durationSec: 8.0,
    cam: { theta: 0.58, phi: 0.98, radius: 31.0, target: [0, 1.8, 4.0], autoOrbitSpeed: 0.10 },
    narration: 'This concludes the automated 12-scene demonstration. You can now click any component in the 3D farm—Camera, ESP32, LoRa Node, Thermal Lens, Sensor, Animal, or Gateway—to zoom in and inspect it live with the jury!'
  }
];

// Detailed Inspection Catalog for the 7 Key Objects (Requirement D)
const DETAILED_INSPECTION_OBJECTS = {
  camera: {
    id: 'camera',
    title: 'Dual Optical + Gimbal AI Camera Unit (CAM_01)',
    category: 'OPTICAL VISION & AI INFERENCE',
    camPose: { theta: 0.18, phi: 1.25, radius: 3.2, target: [0, 5.45, 0.45] },
    specs: [
      ['Sensor & Lens', 'Sony IMX335 5MP Starlight CMOS • 4mm f/1.6 Wide-Angle IR-Cut Lens'],
      ['Mounting & Gimbal', 'Weatherproof IP66 Pan-Tilt Gimbal on 5.5m Galvanized Lattice Tower'],
      ['AI Model Pipeline', 'YOLOv8 Wildlife Model (Elephant, Wild Boar, Deer, Monkey, Human)'],
      ['False-Positive Filter', 'Requires 4 consecutive confirmed frames ≥70% confidence']
    ],
    explanation: 'Continuously scans the forest approach corridor, draws bounding boxes around detected wildlife, and streams class + confidence packets to the ESP32 controller.'
  },
  thermal: {
    id: 'thermal',
    title: 'LWIR Thermal & IR Night-Vision Imaging Module',
    category: 'NIGHT & FOG THERMAL FUSION',
    camPose: { theta: -0.25, phi: 1.22, radius: 3.1, target: [0, 5.15, 0.52] },
    specs: [
      ['Thermal Detector', 'Uncooled VOx Microbolometer (8–14 µm LWIR Spectral Band)'],
      ['IR Illuminator', '850nm High-Power LED Array (35m Night-Vision Range)'],
      ['All-Weather Role', 'Detects warm-blooded animal heat signatures in total darkness & fog'],
      ['Spectral Modes', 'Visible RGB • Emerald IR Night-Vision • FLIR Ironbow Thermal']
    ],
    explanation: 'Mounted directly beneath the optical camera on the tower head. Allows WildGuard AI to spot nocturnal elephants and wild boars in zero-lux darkness or monsoon mist.'
  },
  esp32: {
    id: 'esp32',
    title: 'ESP32 Edge Control Unit (IP65 Tower Enclosure)',
    category: 'EDGE MICROCONTROLLER & STATE MACHINE',
    camPose: { theta: 0.12, phi: 1.18, radius: 3.4, target: [0, 2.2, 0.55] },
    specs: [
      ['Microcontroller', 'ESP32-WROOM-32 Dual-Core 240 MHz • 3.3V CMOS Logic'],
      ['Pin Assignments', 'GPIO 16/17 (LiDAR UART2) • GPIO 5/18 (Ultrasonic w/ 1kΩ+2kΩ Divider)'],
      ['Actuator Outputs', 'GPIO 19 (Warning LED via 220Ω) • GPIO 23 (Transistor Buzzer Driver)'],
      ['Safety Protections', 'Human Silent Rule • 30s Max Continuous Sound Cutoff • 3.33V Safe Divider']
    ],
    explanation: 'Fuses AI species confirmation with physical distance measurements every 100ms to control Zone 1 (Safe), Zone 2 (Warning), and Zone 3 (Critical Alert) outputs at the edge.'
  },
  sensor: {
    id: 'sensor',
    title: 'Benewake TF02-Pro IP65 Outdoor ToF LiDAR Sensor',
    category: 'PRECISION DISTANCE RANGING',
    camPose: { theta: -0.18, phi: 1.20, radius: 3.0, target: [0, 1.55, 0.60] },
    specs: [
      ['Operating Range', '0.10 m to 40.0 m (Supports 15.0m Warning & 5.0m Critical Zones)'],
      ['Accuracy & Rate', '±5 cm accuracy • 100 Hz Time-of-Flight laser ranging'],
      ['Enclosure Rating', 'IP65 Weatherproof & Dustproof (905nm Eye-Safe Class 1 Laser)'],
      ['Lab Alternative', 'HC-SR04 supported strictly for 0.02m–4.00m indoor bench demos']
    ],
    explanation: 'Measures exact physical distance in metres and centimetres so the system knows precisely when a confirmed animal crosses into the Warning or Critical crop zones.'
  },
  lora_node: {
    id: 'lora_node',
    title: 'Solar-Powered Field LoRa Sensor & Camera Node (NODE_01)',
    category: 'PERIMETER LORA MESH TELEMETRY',
    camPose: { theta: 0.45, phi: 1.15, radius: 4.8, target: [11.5, 2.4, 14.0] },
    specs: [
      ['Transceiver Chip', 'Semtech SX1276 / SX1262 LoRa Module (433 / 868 MHz ISM Band)'],
      ['Antenna & Range', '5 dBi Fiberglass Whip Antenna • Up to 5 km Line-of-Sight Farm Range'],
      ['Power System', '15W Monocrystalline Solar Panel + LiFePO4 Battery Pack'],
      ['Coverage Role', 'Eliminates perimeter blind spots and relays detections to Gateway']
    ],
    explanation: 'Positioned along the outer warning boundary to extend camera and sensor coverage across large farms where Wi-Fi cannot reach.'
  },
  gateway: {
    id: 'gateway',
    title: 'Central Farmhouse LoRaWAN Gateway & Monitoring Station',
    category: 'CENTRAL COMMAND & OFFLINE QUEUE GATEWAY',
    camPose: { theta: -0.65, phi: 1.10, radius: 8.5, target: [-9.5, 2.6, -4.0] },
    specs: [
      ['Gateway Radio', '8-Channel LoRaWAN Concentrator + Wi-Fi / 4G LTE Backhaul'],
      ['Connected Nodes', '4 Active Nodes (TOWER_MAIN, NODE_01 North, NODE_02 East, NODE_03 West)'],
      ['Offline Resilience', 'Persistent SQLite / LocalStorage Queue (Shows PENDING when offline)'],
      ['Fence Supervision', 'Monitors non-lethal perimeter fence loop continuity (100% Intact)']
    ],
    explanation: 'Receives real-time LoRa packets from all field nodes, triggers the Farmer Mobile Phone alert inside the farmhouse, and stores offline alerts during storms.'
  },
  animal: {
    id: 'animal',
    title: 'Tracked Wildlife Target (Live 3D Kinematic Entity)',
    category: 'LIVE AI & RANGING TARGET TELEMETRY',
    camPose: { theta: 0.50, phi: 1.15, radius: 6.5, target: [0, 1.5, 14.0], followTarget: true },
    specs: [
      ['Tracked Species', 'Dynamic (Elephant / Wild Boar / Deer / Monkey / Human Safety Check)'],
      ['Data Source Label', 'SIMULATED 3D DIGITAL TWIN (Clearly separated from Real Hardware)'],
      ['Behavioral State', 'Closed-Loop State Machine (Approaching -> Startled -> Retreating)'],
      ['Welfare Compliance', 'Non-lethal acoustic/visual deterrence with 30s auto-cooldown']
    ],
    explanation: 'Demonstrates closed-loop wildlife response to Zone 2 warning alarms or Zone 3 critical breaches without using hardcoded outcome strings.'
  }
};
