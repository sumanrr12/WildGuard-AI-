// ============================================================================
// WILDGUARD AI 3.0 — MODULE 4: 9-STEP SETUP WIZARD, BEGINNER/EXPERT MODES,
// HELP SYSTEM, FIELD RELIABILITY & GENUINE 10-SCENARIO AUTOMATED TEST ENGINE
// File: src/js/04_wizard_help_and_ui_extensions.js
// ============================================================================

const WIZARD_9_STEPS = [
  {
    step: 1,
    title: 'Step 1 of 9: Welcome to WildGuard AI 3.0',
    subtitle: 'Smart Crop Protection, AI Wildlife Detection & 3D Electronics Laboratory',
    bodyHtml: `
      <div class="space-y-3 text-slate-200 text-xs sm:text-sm leading-relaxed">
        <p>Welcome! <strong>WildGuard AI 3.0</strong> helps farmers, students, teachers, and engineers protect agricultural crops from wildlife intrusion safely and humanely.</p>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          <div class="bg-slate-900 border border-emerald-500/40 rounded-xl p-3">
            <div class="font-bold text-emerald-400 mb-1">1. Zero Technical Jargon</div>
            <p class="text-xs text-slate-300">Beginner Mode guides you step by step in plain English with clear visual buttons.</p>
          </div>
          <div class="bg-slate-900 border border-cyan-500/40 rounded-xl p-3">
            <div class="font-bold text-cyan-300 mb-1">2. 3D Digital Twin &amp; Lab</div>
            <p class="text-xs text-slate-300">Test wildlife scenarios in 3D and assemble the ESP32 circuit with safety checks.</p>
          </div>
          <div class="bg-slate-900 border border-amber-500/40 rounded-xl p-3">
            <div class="font-bold text-amber-300 mb-1">3. Real Hardware Ready</div>
            <p class="text-xs text-slate-300">Connect a real USB camera, ESP32, LiDAR/Ultrasonic sensor, and SMS/Webhook alerts.</p>
          </div>
        </div>
      </div>
    `
  },
  {
    step: 2,
    title: 'Step 2 of 9: Select How You Want to Use WildGuard AI',
    subtitle: 'Choose Simulation Mode, Real Hardware Mode, or Hybrid Mode',
    bodyHtml: `
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <button type="button" data-wizmode="SIMULATED" class="wiz-mode-btn text-left p-3.5 rounded-xl bg-emerald-950/60 border-2 border-emerald-500 hover:bg-emerald-900/50 transition">
          <div class="font-extrabold text-emerald-300 text-sm mb-1">1. Explore Simulation Only</div>
          <p class="text-slate-300">Run the 3D agricultural field, virtual camera, and 3D electronics lab without needing any physical parts.</p>
          <span class="inline-block mt-2 px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">RECOMMENDED FOR FIRST TRY</span>
        </button>
        <button type="button" data-wizmode="REAL_HARDWARE" class="wiz-mode-btn text-left p-3.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-400 transition">
          <div class="font-extrabold text-cyan-300 text-sm mb-1">2. Connect Real Hardware</div>
          <p class="text-slate-300">Connect your physical ESP32 via USB Serial and a real USB Webcam. Only verified hardware readings are shown.</p>
          <span class="inline-block mt-2 px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold text-[10px]">REQUIRES ESP32 + USB</span>
        </button>
        <button type="button" data-wizmode="HYBRID" class="wiz-mode-btn text-left p-3.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-amber-400 transition">
          <div class="font-extrabold text-amber-300 text-sm mb-1">3. Hybrid Digital Twin Mode</div>
          <p class="text-slate-300">Combine real USB Webcam or ESP32 sensor readings with the live 3D farm visualization.</p>
          <span class="inline-block mt-2 px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold text-[10px]">SIMULATION + HARDWARE</span>
        </button>
      </div>
    `
  },
  {
    step: 3,
    title: 'Step 3 of 9: Choose Your Distance Sensor Architecture',
    subtitle: 'Match the sensor to your actual required detection range (No fake 15m HC-SR04 readings!)',
    bodyHtml: `
      <div class="space-y-2.5 text-xs">
        <div class="p-2.5 rounded-lg bg-amber-950/50 border border-amber-500/50 text-amber-200">
          <strong>Important Engineering Fact:</strong> The inexpensive <strong>HC-SR04</strong> ultrasonic sensor only works up to <strong>4.0 metres</strong> indoors. For a real farm with a <strong>15 m Warning Zone</strong>, select the outdoor <strong>TF02-Pro LiDAR (0.1–40m)</strong>.
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button type="button" data-wizsensor="TF02_PRO_LIDAR" class="wiz-sensor-btn text-left p-2.5 rounded-lg bg-emerald-950/60 border-2 border-emerald-500">
            <div class="font-bold text-emerald-300">Benewake TF02-Pro IP65 LiDAR (0.1m – 40.0m)</div>
            <div class="text-[11px] text-slate-300">Outdoor farm sensor • Supports 15m Warning &amp; 5m Critical zones</div>
          </button>
          <button type="button" data-wizsensor="HLK_LD2410_RADAR" class="wiz-sensor-btn text-left p-2.5 rounded-lg bg-slate-900 border border-slate-700">
            <div class="font-bold text-cyan-300">HLK-LD2410 24GHz Radar (0.75m – 6.0m)</div>
            <div class="text-[11px] text-slate-300">All-weather radar • Works in heavy rain, fog &amp; darkness (Warn 5m / Crit 2.5m)</div>
          </button>
          <button type="button" data-wizsensor="JSN_SR04T_ULTRASONIC" class="wiz-sensor-btn text-left p-2.5 rounded-lg bg-slate-900 border border-slate-700">
            <div class="font-bold text-sky-300">JSN-SR04T Waterproof Ultrasonic (0.25m – 4.5m)</div>
            <div class="text-[11px] text-slate-300">IP66 outdoor probe • Short-range gate protection (Warn 3.5m / Crit 1.5m)</div>
          </button>
          <button type="button" data-wizsensor="HC_SR04_LAB" class="wiz-sensor-btn text-left p-2.5 rounded-lg bg-slate-900 border border-slate-700">
            <div class="font-bold text-amber-300">HC-SR04 Lab Bench Sensor (0.02m – 4.0m Max)</div>
            <div class="text-[11px] text-slate-300">Indoor tabletop demo only • Strictly capped at 4.0m (Warn 2.5m / Crit 1.0m)</div>
          </button>
        </div>
      </div>
    `
  },
  {
    step: 4,
    title: 'Step 4 of 9: Follow the Visual Assembly Instructions',
    subtitle: 'Ensure safe 3.3V ESP32 GPIO connections and common ground',
    bodyHtml: `
      <div class="space-y-2 text-xs text-slate-200">
        <p>Whether you are building on a physical breadboard or in our <strong>3D Assembly Lab</strong>, verify these 4 safety rules:</p>
        <ul class="list-disc list-inside space-y-1.5 bg-slate-900 border border-slate-800 rounded-xl p-3">
          <li><strong class="text-emerald-300">Rule 1 (3.3V GPIO Protection):</strong> If using a 5V ultrasonic sensor (HC-SR04 / JSN-SR04T), pass the <code>ECHO</code> pin through a <strong>1kΩ + 2kΩ voltage divider</strong> to step 5.0V down to <strong>3.33V</strong> before entering <code>ESP32 GPIO 18</code>.</li>
          <li><strong class="text-cyan-300">Rule 2 (LED Current Limit):</strong> Connect <code>ESP32 GPIO 19</code> through a <strong>220Ω resistor</strong> to the LED Anode (+).</li>
          <li><strong class="text-amber-300">Rule 3 (Transistor Buzzer Driver):</strong> Connect <code>ESP32 GPIO 23</code> to the 3-pin transistor-buffered Active Buzzer module <code>I/O</code> pin.</li>
          <li><strong class="text-slate-300">Rule 4 (Common Ground):</strong> Connect <code>ESP32 GND</code> to the breadboard ground rail shared by all parts.</li>
        </ul>
      </div>
    `
  },
  {
    step: 5,
    title: 'Step 5 of 9: Connect Your Camera (Optional for Simulation)',
    subtitle: 'Use the 3D Virtual Tower Camera or plug in a real USB Webcam',
    bodyHtml: `
      <div class="space-y-2.5 text-xs text-slate-200">
        <p>WildGuard AI supports two camera sources:</p>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div class="p-3 rounded-xl bg-slate-900 border border-emerald-500/40">
            <div class="font-bold text-emerald-300 mb-1">A. 3D Virtual Tower Camera (Active by Default)</div>
            <p class="text-slate-300">Automatically tracks 3D wildlife in the simulated farm and demonstrates consecutive-frame confirmation.</p>
          </div>
          <div class="p-3 rounded-xl bg-slate-900 border border-cyan-500/40">
            <div class="font-bold text-cyan-300 mb-1">B. Real USB Webcam + Python YOLO Bridge</div>
            <p class="text-slate-300">Click <strong>"Start Real USB Webcam"</strong> in the Device Connection panel or run <code>wildguard_ai_serial_bridge.py</code> for live YOLOv8 inference.</p>
          </div>
        </div>
      </div>
    `
  },
  {
    step: 6,
    title: 'Step 6 of 9: Connect ESP32 via USB (If Using Physical Hardware)',
    subtitle: 'Two-way Web Serial communication at 115200 baud',
    bodyHtml: `
      <div class="space-y-2 text-xs text-slate-200">
        <p>If you have a physical ESP32 board plugged into your computer's USB port:</p>
        <ol class="list-decimal list-inside space-y-1.5 bg-slate-900 border border-slate-800 rounded-xl p-3">
          <li>Upload <code>esp32_wildguard_firmware.ino</code> using Arduino IDE.</li>
          <li>Close the Arduino Serial Monitor so the port is free.</li>
          <li>Click <strong>"Connect ESP32 via USB"</strong> in the Device Connection screen.</li>
          <li>WildGuard AI will verify the two-way <code>WG3</code> handshake before showing <strong>REAL HARDWARE VERIFIED</strong>.</li>
        </ol>
      </div>
    `
  },
  {
    step: 7,
    title: 'Step 7 of 9: Configure Farmer Alert & Deterrent Safety Limits',
    subtitle: 'Humane wildlife protection & verified notification settings',
    bodyHtml: `
      <div class="space-y-2 text-xs text-slate-200">
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-2">
          <div><strong class="text-emerald-300">Human Safety Rule:</strong> When a human is detected, the acoustic alarm and strobe stay strictly <strong>OFF</strong>.</div>
          <div><strong class="text-amber-300">Animal Welfare Sound Limit:</strong> Acoustic deterrents automatically pause after <strong>30 seconds</strong> of continuous operation so animals are not harmed or habituated.</div>
          <div><strong class="text-sky-300">Honest SMS / Webhook Status:</strong> Offline alerts are saved as <strong>PENDING</strong> in persistent storage and never falsely marked as delivered until confirmed.</div>
        </div>
      </div>
    `
  },
  {
    step: 8,
    title: 'Step 8 of 9: Connection & Electrical Safety Check',
    subtitle: 'Automated pre-flight verification complete',
    bodyHtml: `
      <div class="bg-emerald-950/50 border border-emerald-500/50 rounded-xl p-3.5 text-xs space-y-1.5 text-emerald-200">
        <div class="font-extrabold text-sm text-emerald-300">✓ All Pre-Flight Safety Checks Passed</div>
        <div>• 3.3V ESP32 GPIO voltage divider protection verified (3.33V safe ECHO level).</div>
        <div>• False proxy species mappings (dog→monkey, sheep→deer, bear→boar) strictly disabled.</div>
        <div>• Sensor range boundaries enforced for active sensor profile.</div>
        <div>• Persistent local storage initialized for detections and offline alerts.</div>
      </div>
    `
  },
  {
    step: 9,
    title: 'Step 9 of 9: Ready to Start Monitoring!',
    subtitle: 'You can re-open this Setup Wizard or switch between Beginner & Expert Mode anytime',
    bodyHtml: `
      <div class="text-center py-3 space-y-2 text-xs sm:text-sm text-slate-200">
        <div class="text-lg font-extrabold text-emerald-400">You are all set to operate WildGuard AI 3.0!</div>
        <p class="text-slate-300 max-w-xl mx-auto">Click <strong>"Finish &amp; Start Monitoring"</strong> below to enter the application. Use the large top buttons to switch between the <strong>Home Dashboard</strong>, <strong>3D Farm Simulation</strong>, <strong>3D Electronics Lab</strong>, <strong>Device Connection</strong>, and <strong>Reports &amp; 10 Tests</strong>.</p>
      </div>
    `
  }
];

// Contextual Help Dictionary (What is this? What does it do? Why is it needed? How do I use it? What if it fails?)
const HELP_KNOWLEDGE_BASE = [
  {
    title: '1. 3D Wildlife Protection Simulation (Environment A)',
    whatIsIt: 'An interactive 3D digital replica of an agricultural farm, crop boundary, monitoring tower, and approaching wildlife.',
    whatDoesItDo: 'Shows step by step how the camera spots an animal, how the AI confirms the species over 4 frames, how the distance sensor measures metres, and how the ESP32 triggers the warning buzzer or farmer phone alert.',
    whyNeeded: 'Lets farmers, students, and engineers test all 10 wildlife intrusion and safety scenarios safely before installing hardware in the field.',
    howToUse: 'Click Elephant, Wild Boar, Deer, Monkey, or Human on the left panel, choose how the animal reacts to the alarm, and watch the 3D scene.',
    ifItFails: 'If the 3D scene feels slow on an older laptop, click the "Low-Perf Graphics" button in the top bar to boost frame rate.'
  },
  {
    title: '2. 3D Component Assembly Laboratory (Environment B)',
    whatIsIt: 'A virtual electronics workbench with 13 realistic 3D parts (ESP32, breadboard, TF02-Pro LiDAR / HC-SR04, resistors, LED, active buzzer, wires).',
    whatDoesItDo: 'Lets you place parts, route color-coded jumper wires between pins, inspect a synchronized 2D circuit schematic, and check for dangerous wiring errors.',
    whyNeeded: 'Connecting a 5V ultrasonic ECHO signal directly to a 3.3V ESP32 pin can permanently damage the board. The lab teaches and validates safe wiring first.',
    howToUse: 'Use the Guided Assembly Tutorial on the left of the lab, or pick any two pins and click "+ Connect Jumper Wire". Switch tabs to view the 2D Schematic or Pinout Table.',
    ifItFails: 'If you make a wiring mistake (shown in red), click "✓ Auto-Build Verified Circuit (100%)" to restore the safe reference circuit.'
  },
  {
    title: '3. Distance Sensors (TF02-Pro LiDAR vs. HC-SR04)',
    whatIsIt: 'Physical ranging hardware that measures the exact distance (in metres and centimetres) between the tower and the approaching animal.',
    whatDoesItDo: 'Tells the ESP32 whether the confirmed animal is in Zone 1 (Safe), Zone 2 (Warning — turn on buzzer/LED), or Zone 3 (Critical — notify farmer).',
    whyNeeded: 'A single 2D camera cannot accurately judge distance at night or in fog. Combining AI vision (who is it?) with LiDAR/Radar ranging (how close is it?) prevents false alarms.',
    howToUse: 'Select your installed sensor in the Sensor Architecture selector. Use TF02-Pro LiDAR for 15m/5m outdoor farm zones, or HC-SR04 for 0.02m–4.0m indoor tabletop demos.',
    ifItFails: 'If the sensor shows OUT OF RANGE, check that your target is within the sensor’s physical limit (40m for TF02-Pro LiDAR, 4.0m max for HC-SR04).'
  },
  {
    title: '4. AI Wildlife Detection & Human Safety Filter',
    whatIsIt: 'Computer vision software (YOLOv8) that classifies objects in camera frames and filters out false positives.',
    whatDoesItDo: 'Identifies Elephant, Wild Boar, Deer, Monkey, and Human. Requires 4 consecutive confirmed frames above 70% confidence before acting.',
    whyNeeded: 'Prevents wind-blown branches, birds, or dogs from triggering false alarms, and ensures the loud deterrent never blasts at a human farmer.',
    howToUse: 'Adjust the Minimum Confidence and Confirmation Frames sliders, or connect a USB webcam and run wildguard_ai_serial_bridge.py.',
    ifItFails: 'If a standard COCO model is loaded, it only recognizes Elephant and Human. Load a custom wildlife-trained YOLO model (.pt) to detect Wild Boar, Deer, and Monkey.'
  },
  {
    title: '5. ESP32 USB Connection & Farmer Notification Queue',
    whatIsIt: 'Two-way USB Serial communication with the ESP32 microcontroller and an HTTP Webhook/SMS alert dispatcher with offline storage.',
    whatDoesItDo: 'Exchanges live JSON telemetry with the ESP32 and sends critical Zone 3 alerts to the farmer’s phone (or saves them as PENDING when offline).',
    whyNeeded: 'Farms often lose Wi-Fi or cellular signal during storms. The local ESP32 alarm still protects the crops immediately, and queued alerts are sent as soon as signal returns.',
    howToUse: 'Open Device Connection to plug in your ESP32 over USB or enter your Webhook/SMS API URL.',
    ifItFails: 'If USB connection fails, verify you are using Chrome or Edge, check that your USB cable supports data (not charge-only), and close the Arduino Serial Monitor.'
  }
];
