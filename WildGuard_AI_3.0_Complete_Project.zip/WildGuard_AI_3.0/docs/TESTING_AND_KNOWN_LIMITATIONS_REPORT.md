# WILDGUARD AI — 20-TEST VERIFICATION REPORT & KNOWN LIMITATIONS

## 1. Circuit Simulation Engine Architecture & Honest Technical Scope
WildGuard AI's virtual hardware laboratory uses a documented **5-Layer Hybrid Nodal DC + Discrete-Event Digital Logic & Sensor Physics Engine (`WildGuardCircuitEngine`)**:
1. **Electrical DRC & Nodal DC Analyzer**: Computes steady-state rail voltages (`7.40V Battery -> 5.00V Buck -> 3.30V LDO`), resistive voltage divider outputs (`V_GPIO18 = 5.00V × 2000Ω / (1000Ω + 2000Ω) = 3.33V`), LED series branch currents (`I_Red = (3.30V - 2.00V) / 220Ω = 5.91mA`), and BJT base/collector currents (`I_Base = 2.60mA`, `I_Collector = 30.0mA`), while flagging shorts, open grounds, and 5V-to-3.3V overvoltage faults.
2. **Official 7-State Status Machine**: Dynamically computes `NOT ASSEMBLED`, `ASSEMBLY IN PROGRESS`, `CONNECTION ERRORS`, `ELECTRICAL CHECK REQUIRED`, `READY TO POWER ON`, `SIMULATION RUNNING`, and `FAULT DETECTED`.
3. **Virtual ESP32 Firmware & GPIO Register Engine**: Simulates boot stages (`POWER_OFF -> ROM_BOOT -> GPIO_INIT -> RUNNING_LOOP`) and GPIO pin states (`GPIO 2, 5, 16, 17, 18, 19, 21, 23, 27`).
4. **Sensor Time-of-Flight Physics**: Computes acoustic/laser echo delay (`t_us = dist_cm × 58.3`) from either the workbench's movable 3D target or coupled Environment A wildlife distance.
5. **Physical Hardware Separation**: Simulated values are explicitly labeled `SIMULATED`; `REAL HARDWARE VERIFIED` only appears when a physical ESP32 exchanges valid `WG3` JSON frames over Web Serial (`115200 8N1`).

### Known Limitations (Explicitly Documented per Section 9 & 22)
- **Why Full Nonlinear Transient SPICE Is Not Used**: Solving stiff nonlinear differential-algebraic SPICE matrices at microsecond resolution (e.g., 433MHz RF carrier waveforms or 150kHz buck converter switching ripples) inside a single-threaded browser tab would drop 3D WebGL frame rates below 5 FPS on student laptops. Instead, our Hybrid Nodal DC + Discrete-Event Engine solves exact DC node voltages, Ohm's Law branch currents, and digital state propagation at 60 FPS.
- **3D Model Dimensional Fidelity**: Standard package dimensions (ESP32 DevKit V1 `55×28×13mm`, HC-SR04 `45×20×15mm`, TF02-Pro `69×41.5×26mm`, 0.25W resistors, 5mm LEDs, TO-92 NPN, SX1278) follow manufacturer datasheets; custom assemblies (`IR/Thermal Dual Pod`, `Scaled Solar Panel`) are clearly labeled as *"Scaled Illustrative Engineering Models"* in the Component Inspector.
- **High-Voltage Electric Fence Exclusion**: Per safety rules, hazardous high-voltage electric-fence energizers are excluded from the low-voltage (`3.3V / 5.0V / 7.4V`) breadboard laboratory.

## 2. Execution Results of the 20 Strict Functional Acceptance Tests

| Test # | Functional Requirement | Executed Verification Method | Actual Result | Status |
| :--- | :--- | :--- | :--- | :--- |
| **1** | All required components in library | Inspected `LAB_COMPONENTS_CATALOG` & `labComponentMeshes` | 24 interactive 3D components registered & meshed | **PASS** |
| **2** | Components move (X/Y/Z) & rotate | Applied `ΔX=+0.50` & `Δθ=+45°` to `esp32` mesh | 3D position and rotation updated accurately | **PASS** |
| **3** | Component pins selectable | Checked `LAB_PINS` & `labPinSphereMeshes` | 38 selectable 3D pin spheres + dropdowns active | **PASS** |
| **4** | Wires snap to 3D pin coordinates | Built complete circuit & inspected `wires` group | 27 CatmullRom 3D wires + 54 Dupont housings snapped | **PASS** |
| **5** | Correct connections accepted | Evaluated `classifyPinConnection('HCSR04_TRIG','ESP32_GPIO5')` | Accepted with `valid=true, reqId=conn_trig_gpio5` | **PASS** |
| **6** | Incorrect connections flagged/rejected | Evaluated `HCSR04_ECHO->ESP32_GPIO18` & `5V->LORA_3V3` | Both flagged (`valid=false, dangerous=true`) with fix advice | **PASS** |
| **7** | Missing connections identified | Removed `conn_trig_gpio5` & ran DRC | Missing count = `1`, Status = `ASSEMBLY IN PROGRESS` | **PASS** |
| **8** | Voltage compatibility checked | Solved `1kΩ + 2kΩ` divider with `5.00V` ECHO input | `V_DividerJunc = 3.33V` verified safe for GPIO 18 | **PASS** |
| **9** | Status reflects actual validation | Tested Empty -> Wired (Power OFF) -> Power ON | Transitions: `NOT ASSEMBLED -> READY TO POWER ON -> SIMULATION RUNNING` | **PASS** |
| **10** | Power ON starts virtual circuit | Called `setCircuitPower(true)` | `V_5V=5.00V, V_3V3=3.30V`, boot sequence active | **PASS** |
| **11** | Power OFF stops component behaviour | Called `setCircuitPower(false)` | Rails `0.00V`, all LEDs OFF, Buzzer SILENT, LoRa OFF | **PASS** |
| **12** | Sensor readings change with distance | Moved 3D target from `120 cm` to `285 cm` | HUD updated live from `120 cm (1.20m)` to `285 cm (2.85m)` | **PASS** |
| **13** | 3D LEDs respond to system conditions | Toggled normal vs warning vs LoRa TX state | Green (`GPIO 2`), Red (`GPIO 19`), Blue (`GPIO 21`) 3D domes illuminate | **PASS** |
| **14** | 3D Buzzer responds to warnings | Triggered Zone 2 warning while powered ON | 3D Buzzer vibrates & expands sound-wave rings (`30mA`) | **PASS** |
| **15** | LoRa simulated with packet status | Triggered `triggerLoraPacketBurst()` | Animated 3D RF packet to Gateway (`RSSI -71 dBm, SNR +9.4 dB`) | **PASS** |
| **16** | Comm/wire failure produces visible fault | Injected `loraFailed=true` & broken buzzer wire | Status = `FAULT DETECTED`, LoRa = `LINK_FAULT`, logged to history | **PASS** |
| **17** | Farm (Env A) & Lab (Env B) synchronized | Disconnected buzzer in Lab during Farm warning | `simState.soundEnabled` immediately updated to `false` in Env A | **PASS** |
| **18** | 2D schematic updates on 3D wire change | Compared SVG output before/after wire changes | 2D SVG schematic & pin highlights updated automatically | **PASS** |
| **19** | Assembly saved & restored persistently | Executed `saveLabAssemblyToStorage()` & `loadLabAssemblyFromStorage()` | Restored all 27 wires & 24 3D component coordinates from `localStorage` | **PASS** |
| **20** | Jury Presentation Mode works end-to-end | Executed `startJury10StopHardwarePresentation()` (Stops 1–10) | Verified all 10 camera stops, HUD labels, and pause/resume controls | **PASS** |
