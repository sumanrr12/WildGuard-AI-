# WildGuard AI 3.0 — Real-Time AI Wildlife Detection, Smart Crop Protection & Interactive 3D Engineering Laboratory

## 1. Project Overview
**WildGuard AI 3.0** is an integrated agricultural crop protection system, real-time AI computer vision bridge, ESP32 hardware firmware suite, and interactive 3D engineering laboratory. It protects farm perimeters from crop-raiding wildlife (**Elephant**, **Wild Boar**, **Deer**, **Monkey**) while enforcing a strict **Human Safety Rule** (never activating acoustic or visual deterrents when a human is detected) and maintaining strict separation between **Simulation Mode**, **Hybrid Mode**, and **Verified Real Hardware Mode**.

## 2. System Architecture
WildGuard AI 3.0 is organized into modular layers:
- **Modular Frontend (`src/css/`, `src/js/`, and compiled `index.html`)**:
  - `src/css/wildguard.css`: High-contrast responsive agricultural & engineering UI supporting Beginner Mode and Expert Mode.
  - `src/js/01_sensors_and_storage.js`: Multi-sensor physical range catalog, strict anti-proxy wildlife class mapper, `localStorage` persistence manager, and CSV/PDF report exporter.
  - `src/js/02_hardware_serial_and_camera.js`: Two-way Web Serial API communicator (`WG3` JSON protocol with handshake verification) and browser USB Webcam (`getUserMedia`) capture.
  - `src/js/03_dynamic_schematic_and_pinout.js`: Real-time synchronized 2D SVG circuit schematic generator and 30-pin ESP32 DevKit V1 electrical pinout monitor.
  - `src/js/04_wizard_help_and_ui_extensions.js`: First-time 9-Step Setup Wizard, Contextual Help Knowledge Base, Weather/Field Reliability Simulator, and State-Machine Test Runner.
  - `src/js/05_core_application.js`: Three.js 3D Digital Twin (Environment A) & 3D Component Assembly Laboratory (Environment B) coupling engine.
- **Python AI Vision & Local IoT Server Bridge (`python_ai_bridge/wildguard_ai_serial_bridge.py`)**:
  - Captures live frames from a USB webcam or RTSP camera via OpenCV (`cv2.VideoCapture`).
  - Loads Ultralytics YOLOv8/v11 `.pt` or `.onnx` models, enforces consecutive-frame temporal confirmation, rejects false proxy classes (`dog`, `sheep`, `bear`), persists events and offline alerts in SQLite (`wildguard_data.db`), and exchanges `WG3` JSON packets with the ESP32 over USB Serial.
- **ESP32 Microcontroller Firmware (`esp32_wildguard_firmware/esp32_wildguard_firmware.ino`)**:
  - Supports outdoor UART LiDAR (`Benewake TF02-Pro`), 24GHz Radar (`HLK-LD2410`), waterproof ultrasonic (`JSN-SR04T`), and indoor bench ultrasonic (`HC-SR04` strictly capped at `0.02m–4.00m`).
  - Executes edge decision logic, enforces a 30-second maximum continuous acoustic deterrent cutoff for animal welfare, and manages an offline alert queue.

## 3. Hardware List & Sensor Selection Engineering
| Component | Recommended Model | Operating Range / Specs | Role in WildGuard AI 3.0 |
| :--- | :--- | :--- | :--- |
| **Microcontroller** | ESP32 DevKit V1 (ESP-WROOM-32) | Dual-core 240MHz, **3.3V GPIO logic (12mA max)** | Edge state machine, sensor fusion, GPIO control & Wi-Fi IoT |
| **Primary Outdoor Sensor** | **Benewake TF02-Pro IP65 ToF LiDAR** | **0.10 m – 40.0 m** (±5 cm, UART 3.3V) | **Recommended for 15 m Warning & 5 m Critical farm zones** |
| **Mid-Range Gate Sensor** | Benewake TF-Luna LiDAR | 0.20 m – 8.0 m (±2 cm, UART/I2C 3.3V) | Medium-range orchard gates (6.5 m Warning / 3.0 m Critical) |
| **All-Weather Radar** | HLK-LD2410 24GHz FMCW Radar | 0.75 m – 6.0 m (UART 3.3V, IP65 housing) | Immune to heavy rain, dense fog, dust, and darkness |
| **Short-Range Outdoor** | JSN-SR04T Waterproof Ultrasonic | 0.25 m – 4.5 m (IP66 probe, 5V w/ divider) | Short-range fence gap sensor (3.5 m Warning / 1.5 m Critical) |
| **Indoor Lab Demo Only** | **HC-SR04 Ultrasonic Sensor** | **0.02 m – 4.00 m STRICT MAX** (5V w/ divider) | **Classroom tabletop demo ONLY (2.5 m Warn / 1.0 m Crit — never 15 m!)** |
| **AI Vision Camera** | USB HD Webcam (UVC) or RTSP IP Cam | 720p/1080p @ 30 FPS | Optical video feed for YOLOv8 wildlife classification |
| **Voltage Divider** | `1 kΩ` + `2 kΩ` Axial Resistors (0.25W) | Steps 5.0V ECHO down to **3.33V** | Protects 3.3V-only `ESP32 GPIO 18` from 5V overvoltage |
| **LED Current Limiter** | `220 Ω` Axial Resistor + 5mm Red LED | `(3.3V - 2.0V)/220Ω = 5.9 mA` | Safe visual warning indicator on `ESP32 GPIO 19` |
| **Acoustic Deterrent** | 3-Pin Active Buzzer Module (NPN Driver) | 5V VCC, `<2 mA` base trigger on `GPIO 23` | Humane pulsed acoustic deterrent (auto-cutoff at 30s) |

## 4. Software Requirements
- **Browser (for 3D Digital Twin, 3D Assembly Lab & Web Serial API)**: Google Chrome 89+ or Microsoft Edge 89+ on Windows 10/11, macOS, or Linux.
- **Python Environment (for Real Camera YOLOv8 Inference & Serial Bridge)**: Python 3.9 – 3.12 with `opencv-python`, `ultralytics`, `pyserial`, and `numpy`.
- **Arduino IDE (for ESP32 Firmware)**: Arduino IDE 2.x with `esp32` board manager installed.

## 5. Installation Guide (Windows Step-by-Step)
1. **Unzip the Package**: Extract `WildGuard_AI_3.0_Complete_Project.zip` to a folder such as `C:\WildGuard_AI_3.0`.
2. **Launch the 3D Application & Lab**: Double-click `index.html` to open it in Chrome or Edge, or run a local server:
   ```cmd
   cd C:\WildGuard_AI_3.0
   python -m http.server 8080
   ```
   Then open `http://localhost:8080` in Chrome or Edge.
3. **Install Python AI Bridge Dependencies (Optional for Real Camera + YOLO)**:
   ```cmd
   cd C:\WildGuard_AI_3.0\python_ai_bridge
   pip install -r requirements.txt
   ```

## 6. Wiring Guide & Real Hardware Electrical Safety
- **Mandatory 3.3V GPIO Rule**: ESP32 GPIO pins are **not** 5V-tolerant. When using a 5V ultrasonic sensor (`HC-SR04` or `JSN-SR04T`), never wire `ECHO` directly to `GPIO 18`. Always wire `ECHO -> 1kΩ Resistor -> Junction -> GPIO 18` and `Junction -> 2kΩ Resistor -> Common GND` (`V_out = 5.0V * 2000 / 3000 = 3.33V`).
- **LED Series Resistor**: Always place a `220 Ω` resistor between `GPIO 19` and the LED Anode (+).
- **Transistor-Buffered Buzzer**: Drive the buzzer via a 3-pin NPN transistor-buffered module (`VCC -> 5V`, `I/O -> GPIO 23`, `GND -> Common GND`) or opto-isolated relay module so GPIO pin current stays below `2 mA`.
- **Common Ground**: Connect `ESP32 GND`, sensor `GND`, the `2kΩ` divider bottom leg, LED cathode (-), and buzzer `GND` to the shared breadboard ground bus.

## 7. 3D Assembly Laboratory Guide
1. Click **3. Hardware Assembly** on the Home Dashboard (or **🔧 3D Component Assembly Lab** in the top bar).
2. Switch between the **4 Synchronized Views**:
   - **1. 3D Assembly View**: Drag components on the workbench, rotate them (`-45°` / `+45°`), toggle **Exploded 3D View**, or import custom `.glb`/`.gltf` CAD files.
   - **2. 2D Circuit Schematic (Synced)**: Watch the 2D vector schematic update live as you connect or remove jumper wires in 3D.
   - **3. ESP32 Pinout View**: Inspect all 30 pins, voltage ratings, and live wiring status.
   - **4. Synchronized Wiring Table**: Verify all 10 required connections.
3. Use the **Pin-to-Pin Jumper Wiring** panel to pick any two pins, choose a **Wire Color**, and click **+ Connect Jumper Wire**. Try clicking **⚡ Test Unsafe 5V→GPIO18 Wire** to see how the Design Rule Checker blocks dangerous 5V overvoltage connections.

## 8. AI Model Setup & Wildlife Class Mapping
- **Supported Target Wildlife Classes**: `elephant`, `wild_boar`, `deer`, `monkey`.
- **Human Safety Class**: `human` (`person`) — enters `HUMAN_DETECTED` state and strictly suppresses all alarms.
- **Zero False Proxy Mappings**: Standard COCO models (`yolov8n.pt`) include `person` and `elephant`, but do **not** include trained classes for `wild_boar`, `deer`, or `monkey`. WildGuard AI 3.0 **never** maps `dog -> monkey`, `sheep -> deer`, or `bear -> wild_boar`. Non-target species are flagged as `UNSUPPORTED_SPECIES (NO ALARM)`.
- **Loading a Custom Wildlife Model**: Train or download a 5-class YOLOv8 wildlife model (`wildguard_wildlife.pt`) and launch:
  ```cmd
  python wildguard_ai_serial_bridge.py --model wildguard_wildlife.pt --class-map custom_classes_example.json --port COM3
  ```

## 9. ESP32 Firmware Setup
1. Open `esp32_wildguard_firmware/esp32_wildguard_firmware.ino` in Arduino IDE.
2. Select **Tools → Board → ESP32 Dev Module** and your COM port.
3. Click **Upload**. Once uploaded, close the Arduino Serial Monitor so Chrome/Edge or the Python bridge can access the serial port.

## 10. Two-Way Serial Communication Protocol (`WG3` JSON @ 115200 8N1)
- **Host → ESP32 Handshake**: `{"proto":"WG3","cmd":"handshake","client":"WildGuard_Web_3.0"}`
- **Host → ESP32 AI Frame**: `{"proto":"WG3","cmd":"ai_frame","class":"elephant","conf":0.94,"frames":4,"warn_m":15.0,"crit_m":5.0}`
- **Host → ESP32 Sensor Config**: `{"proto":"WG3","cmd":"config","sensor":"TF02_PRO_LIDAR","warn_m":15.0,"crit_m":5.0}`
- **Host → ESP32 Safety Override**: `{"proto":"WG3","cmd":"override","disable_deterrent":true,"manual_alarm":false}`
- **ESP32 → Host 10Hz Telemetry**:
  ```json
  {"proto":"WG3","type":"telemetry","seq":42,"source":"REAL_HARDWARE","sensor":"TF02_PRO_LIDAR","sensor_status":"VALID_MEASUREMENT","valid_dist":true,"dist_cm":1240.0,"dist_m":12.40,"state":"WILDLIFE_WARNING","class":"elephant","conf":0.94,"frames":5,"confirmed":true,"alarm":true,"led":true,"queue":0}
  ```

## 11. Simulation Instructions
1. Open the **3D Simulation** view and choose an installed distance sensor (`TF02-Pro LiDAR` for 15m/5m outdoor zones, or `HC-SR04` to observe the 4.0m indoor limit).
2. Click **Elephant**, **Wild Boar**, **Deer**, **Monkey**, **Human (Farmer)**, or **🐕 Test Non-Target Species (Dog / Sheep)**.
3. Select the animal's behavioral response (`A. Retreats immediately`, `B. Hesitates then retreats`, `C. Ignores alarm & enters critical zone`, or `D. Retreats then returns`).
4. Test environmental reliability using the **Field Weather** dropdown (`Clear Day`, `Night`, `Heavy Rain`, `Dense Fog`, `Dust`, `Camera Obstructed`).

## 12. Automated 10-Scenario Test Reports
Run all 10 scenarios either in the browser (**10 Test Scenarios → Run & Verify All 10 Scenarios**) or from the command line:
```cmd
python python_ai_bridge/wildguard_ai_serial_bridge.py --run-self-tests
python tests/test_wildguard_suite.py
```
See `TEST_RESULTS_10_SCENARIOS.md` for the full input/transition/output verification matrix.

## 13. Troubleshooting Guide
- **"We could not connect to your ESP32"**: Check that you are using a USB data cable (not charge-only), install CP2102/CH340 USB drivers, and close the Arduino IDE Serial Monitor.
- **"Sensor status shows OUT_OF_RANGE (>4.0m MAX FOR HC_SR04_LAB)"**: You selected the indoor HC-SR04 sensor while the animal is >4.0m away. Switch the Distance Sensor dropdown to **Benewake TF02-Pro LiDAR (0.1m–40m)** for outdoor farm distances.
- **"Notification status shows PENDING"**: Either the network toggle is set to `OFFLINE` (Test 10) or no external Webhook/SMS endpoint URL has been configured yet in **Device Connection**.

## 14. Known Limitations
1. **Standard COCO Model Class Coverage**: Pre-trained `yolov8n.pt` COCO weights natively detect `elephant` and `person` (`human`), but require fine-tuned wildlife weights to detect `wild_boar`, `deer`, and `monkey` on a real camera.
2. **Simulated Animal Behaviour Disclaimer**: Animal retreat in the 3D simulation is a state-machine behavioral model for testing system logic; real wildlife habituation and acoustic response vary in nature.
3. **3D Component Geometry**: The 13 built-in 3D workbench components are dimensionally scaled visual engineering models (with `.glb`/`.gltf` import support), not manufacturer-certified mechanical STEP files.

## 15. Future Improvements
- Edge NPU acceleration on ESP32-S3 / Raspberry Pi 5 Hailo-8L for standalone low-power inference.
- LoRaWAN multi-node mesh networking across large multi-hectare plantations.
- Thermal / FLIR infrared camera fusion for zero-visibility night and dense-fog detection.
