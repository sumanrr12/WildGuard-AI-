// ============================================================================
// WILDGUARD AI 3.0 — MODULE 3: SYNCHRONIZED 2D SCHEMATIC, PINOUT & GUIDED LAB
// File: src/js/03_dynamic_schematic_and_pinout.js
// ============================================================================

const ESP32_DEVKIT_30_PINS = [
  { pin: 'VIN (5V)', side: 'L', gpio: 'PWR', safeVolt: '5.0V Input/Output', role: 'Supplies 5V to HC-SR04 / Buzzer / LiDAR VCC', statusKey: 'conn_pwr_5v' },
  { pin: 'GND',      side: 'L', gpio: 'GND', safeVolt: '0V Reference',      role: 'Common Ground Reference (Mandatory!)',        statusKey: 'conn_gnd_common' },
  { pin: '3V3',      side: 'L', gpio: 'PWR', safeVolt: '3.3V Regulated',    role: '3.3V Logic Supply (Max 600mA)',               statusKey: null },
  { pin: 'GPIO 5',   side: 'L', gpio: '5',   safeVolt: '3.3V Max',          role: 'Ultrasonic TRIG Output (10µs Pulse)',         statusKey: 'conn_trig_gpio5' },
  { pin: 'GPIO 18',  side: 'L', gpio: '18',  safeVolt: '3.3V Max (NO 5V!)', role: 'Ultrasonic ECHO Input via 1kΩ+2kΩ Divider',   statusKey: 'conn_junc_to_gpio18' },
  { pin: 'GPIO 16',  side: 'R', gpio: '16',  safeVolt: '3.3V UART2 RX',     role: 'TF02-Pro LiDAR / LD2410 Radar UART RX2',      statusKey: 'conn_trig_gpio5' },
  { pin: 'GPIO 17',  side: 'R', gpio: '17',  safeVolt: '3.3V UART2 TX',     role: 'TF02-Pro LiDAR / LD2410 Radar UART TX2',      statusKey: 'conn_junc_to_gpio18' },
  { pin: 'GPIO 2',   side: 'R', gpio: '2',   safeVolt: '3.3V Max (12mA)',   role: 'Green Monitoring Status LED (Onboard)',       statusKey: null },
  { pin: 'GPIO 19',  side: 'R', gpio: '19',  safeVolt: '3.3V Max (12mA)',   role: 'Warning LED Anode via 220Ω Series Resistor',  statusKey: 'conn_gpio19_to_220' },
  { pin: 'GPIO 23',  side: 'R', gpio: '23',  safeVolt: '3.3V Max (12mA)',   role: 'Active Buzzer Module NPN Base Trigger',       statusKey: 'conn_buz_to_gpio23' },
  { pin: 'GPIO 21',  side: 'R', gpio: '21',  safeVolt: '3.3V Max (12mA)',   role: 'Blue IoT Transmission Indicator LED',         statusKey: null },
  { pin: 'GPIO 22',  side: 'R', gpio: '22',  safeVolt: '3.3V Max (12mA)',   role: 'Optional 5V Opto-Isolated Strobe Relay IN',   statusKey: null }
];

// Renders a live 2D SVG Circuit Schematic synchronized with labState.activeWires
function renderSynchronized2DSchematicSVG(activeWires, sensorId) {
  const svgContainer = document.getElementById('liveDynamicSchematicContainer');
  if (!svgContainer) return;

  const hasReq = (reqId) => activeWires.some(w => w.valid && w.reqId === reqId);
  const badDirectEcho = activeWires.some(w => !w.valid && (
    (w.from === 'HCSR04_ECHO' && w.to === 'ESP32_GPIO18') ||
    (w.to === 'HCSR04_ECHO' && w.from === 'ESP32_GPIO18')
  ));

  const strokeFor = (reqId, activeHex) => hasReq(reqId) ? activeHex : '#334155';
  const dashFor   = (reqId) => hasReq(reqId) ? 'none' : '5,5';
  const widthFor  = (reqId) => hasReq(reqId) ? '3' : '1.5';
  const sensorTitle = (SENSOR_CATALOG_3[sensorId] || SENSOR_CATALOG_3.TF02_PRO_LIDAR).shortName;

  svgContainer.innerHTML = `
    <svg viewBox="0 0 880 340" class="w-full h-auto max-w-[880px] mx-auto select-none">
      <rect x="0" y="0" width="880" height="340" rx="12" fill="#07111e"/>
      <!-- Title Banner -->
      <text x="440" y="22" text-anchor="middle" fill="#38bdf8" font-family="monospace" font-size="12" font-weight="bold">
        LIVE SYNCHRONIZED 2D SCHEMATIC (AUTO-GENERATED FROM 3D WORKBENCH WIRING)
      </text>

      <!-- Left Block: Distance Sensor (${sensorTitle}) -->
      <rect x="25" y="65" width="210" height="220" rx="10" fill="#0f172a" stroke="#0284c7" stroke-width="2"/>
      <text x="130" y="90" text-anchor="middle" fill="#38bdf8" font-family="monospace" font-size="11" font-weight="bold">${sensorTitle}</text>
      <text x="130" y="108" text-anchor="middle" fill="#94a3b8" font-family="monospace" font-size="9">Range: ${(SENSOR_CATALOG_3[sensorId]||SENSOR_CATALOG_3.TF02_PRO_LIDAR).minRangeM}m – ${(SENSOR_CATALOG_3[sensorId]||SENSOR_CATALOG_3.TF02_PRO_LIDAR).maxRangeM}m</text>

      <text x="220" y="145" text-anchor="end" fill="#fca5a5" font-family="monospace" font-size="10" font-weight="bold">VCC (5V)</text>
      <text x="220" y="180" text-anchor="end" fill="#38bdf8" font-family="monospace" font-size="10" font-weight="bold">TRIG / TX</text>
      <text x="220" y="215" text-anchor="end" fill="#fde047" font-family="monospace" font-size="10" font-weight="bold">ECHO (5V)</text>
      <text x="220" y="265" text-anchor="end" fill="#94a3b8" font-family="monospace" font-size="10" font-weight="bold">GND</text>

      <!-- Center Block: ESP32 DevKit V1 -->
      <rect x="360" y="55" width="210" height="240" rx="12" fill="#0b291e" stroke="#10b981" stroke-width="2.5"/>
      <text x="465" y="82" text-anchor="middle" fill="#34d399" font-family="monospace" font-size="13" font-weight="bold">ESP32 DEVKIT V1</text>
      <text x="465" y="98" text-anchor="middle" fill="#a7f3d0" font-family="monospace" font-size="9">3.3V CMOS Logic (Max 12mA)</text>

      <text x="372" y="145" fill="#fca5a5" font-family="monospace" font-size="10" font-weight="bold">VIN (5V)</text>
      <text x="372" y="180" fill="#38bdf8" font-family="monospace" font-size="10" font-weight="bold">GPIO 5</text>
      <text x="372" y="215" fill="#4ade80" font-family="monospace" font-size="10" font-weight="bold">GPIO 18</text>
      <text x="372" y="265" fill="#94a3b8" font-family="monospace" font-size="10" font-weight="bold">GND</text>

      <text x="558" y="155" text-anchor="end" fill="#fb7185" font-family="monospace" font-size="10" font-weight="bold">GPIO 19 (LED)</text>
      <text x="558" y="220" text-anchor="end" fill="#fbbf24" font-family="monospace" font-size="10" font-weight="bold">GPIO 23 (BUZ)</text>
      <text x="558" y="265" text-anchor="end" fill="#94a3b8" font-family="monospace" font-size="10" font-weight="bold">GND BUS</text>

      <!-- Sensor to ESP32 Wires -->
      <!-- 1. 5V Power -->
      <line x1="235" y1="141" x2="360" y2="141" stroke="${strokeFor('conn_pwr_5v', '#ef4444')}" stroke-width="${widthFor('conn_pwr_5v')}" stroke-dasharray="${dashFor('conn_pwr_5v')}"/>
      <!-- 2. TRIG -> GPIO 5 -->
      <line x1="235" y1="176" x2="360" y2="176" stroke="${strokeFor('conn_trig_gpio5', '#06b6d4')}" stroke-width="${widthFor('conn_trig_gpio5')}" stroke-dasharray="${dashFor('conn_trig_gpio5')}"/>
      <!-- 3. ECHO -> 1kΩ -> Junction -> GPIO 18 + 2kΩ -> GND -->
      <line x1="235" y1="211" x2="295" y2="211" stroke="${strokeFor('conn_echo_to_1k', '#eab308')}" stroke-width="${widthFor('conn_echo_to_1k')}" stroke-dasharray="${dashFor('conn_echo_to_1k')}"/>
      <rect x="260" y="202" width="36" height="18" rx="3" fill="#1e293b" stroke="${strokeFor('conn_echo_to_1k', '#eab308')}" stroke-width="1.5"/>
      <text x="278" y="214" text-anchor="middle" fill="#fde047" font-family="monospace" font-size="8">1kΩ</text>

      <circle cx="310" cy="211" r="4" fill="${hasReq('conn_junc_to_gpio18') ? '#22c55e' : '#475569'}"/>
      <line x1="310" y1="211" x2="360" y2="211" stroke="${strokeFor('conn_junc_to_gpio18', '#22c55e')}" stroke-width="${widthFor('conn_junc_to_gpio18')}" stroke-dasharray="${dashFor('conn_junc_to_gpio18')}"/>

      <!-- 2kΩ to GND -->
      <line x1="310" y1="211" x2="310" y2="261" stroke="${strokeFor('conn_2k_to_gnd', '#64748b')}" stroke-width="${widthFor('conn_2k_to_gnd')}" stroke-dasharray="${dashFor('conn_2k_to_gnd')}"/>
      <rect x="295" y="226" width="30" height="22" rx="3" fill="#1e293b" stroke="${strokeFor('conn_2k_to_gnd', '#94a3b8')}" stroke-width="1.5"/>
      <text x="310" y="240" text-anchor="middle" fill="#e2e8f0" font-family="monospace" font-size="8">2kΩ</text>

      <!-- Common GND Left -->
      <line x1="235" y1="261" x2="360" y2="261" stroke="${strokeFor('conn_gnd_common', '#64748b')}" stroke-width="${widthFor('conn_gnd_common')}" stroke-dasharray="${dashFor('conn_gnd_common')}"/>

      ${badDirectEcho ? `
        <path d="M 235 211 Q 298 185 360 211" fill="none" stroke="#ef4444" stroke-width="4"/>
        <rect x="248" y="182" width="105" height="18" rx="4" fill="#7f1d1d" stroke="#ef4444"/>
        <text x="300" y="194" text-anchor="middle" fill="#fecaca" font-family="monospace" font-size="8" font-weight="bold">DANGER: 5V SHORT!</text>
      ` : ''}

      <!-- Right Block: LED (220Ω) & Active Buzzer Module -->
      <rect x="655" y="65" width="200" height="220" rx="10" fill="#0f172a" stroke="#f59e0b" stroke-width="2"/>
      <text x="755" y="90" text-anchor="middle" fill="#fbbf24" font-family="monospace" font-size="11" font-weight="bold">ACTUATORS &amp; LED</text>

      <!-- GPIO 19 -> 220Ω -> LED -> GND -->
      <line x1="570" y1="151" x2="680" y2="151" stroke="${strokeFor('conn_gpio19_to_220', '#f43f5e')}" stroke-width="${widthFor('conn_gpio19_to_220')}" stroke-dasharray="${dashFor('conn_gpio19_to_220')}"/>
      <rect x="595" y="142" width="44" height="18" rx="3" fill="#1e293b" stroke="${strokeFor('conn_gpio19_to_220', '#f43f5e')}" stroke-width="1.5"/>
      <text x="617" y="154" text-anchor="middle" fill="#fda4af" font-family="monospace" font-size="8">220Ω</text>

      <circle cx="700" cy="151" r="10" fill="${hasReq('conn_220_to_led') && hasReq('conn_led_to_gnd') ? '#ef4444' : '#1e293b'}" stroke="#f87171" stroke-width="2"/>
      <text x="775" y="155" text-anchor="middle" fill="#f1f5f9" font-family="monospace" font-size="10">Warning LED</text>

      <!-- GPIO 23 -> Buzzer NPN Driver -->
      <line x1="570" y1="216" x2="685" y2="216" stroke="${strokeFor('conn_buz_to_gpio23', '#f59e0b')}" stroke-width="${widthFor('conn_buz_to_gpio23')}" stroke-dasharray="${dashFor('conn_buz_to_gpio23')}"/>
      <circle cx="700" cy="216" r="12" fill="${hasReq('conn_buz_to_gpio23') ? '#d97706' : '#1e293b'}" stroke="#fbbf24" stroke-width="2"/>
      <text x="780" y="220" text-anchor="middle" fill="#fde68a" font-family="monospace" font-size="10">Active Buzzer</text>

      <!-- GND Return Right -->
      <line x1="570" y1="261" x2="700" y2="261" stroke="${strokeFor('conn_led_to_gnd', '#64748b')}" stroke-width="${widthFor('conn_led_to_gnd')}" stroke-dasharray="${dashFor('conn_led_to_gnd')}"/>
    </svg>
  `;
}

// Renders the ESP32 30-Pin Pinout & Electrical Limits Table in the Assembly Lab
function renderEsp32PinoutView(activeWires) {
  const tbody = document.getElementById('labPinoutViewTableBody');
  if (!tbody) return;
  const hasReq = (reqId) => reqId ? activeWires.some(w => w.valid && w.reqId === reqId) : true;

  tbody.innerHTML = ESP32_DEVKIT_30_PINS.map(p => {
    const ok = hasReq(p.statusKey);
    return `
      <tr class="border-b border-slate-800/80 hover:bg-slate-900/60">
        <td class="py-1.5 px-2.5 font-bold text-emerald-300 mono">${p.pin}</td>
        <td class="py-1.5 px-2.5 text-slate-300 mono">${p.side === 'L' ? 'Left Header' : 'Right Header'}</td>
        <td class="py-1.5 px-2.5 text-amber-300 mono">${p.safeVolt}</td>
        <td class="py-1.5 px-2.5 text-slate-200">${p.role}</td>
        <td class="py-1.5 px-2.5">
          <span class="px-2 py-0.5 rounded text-[10px] font-bold mono ${ok ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/25 text-rose-300'}">
            ${ok ? 'CONNECTED ✓' : 'UNWIRED ✕'}
          </span>
        </td>
      </tr>
    `;
  }).join('');
}
