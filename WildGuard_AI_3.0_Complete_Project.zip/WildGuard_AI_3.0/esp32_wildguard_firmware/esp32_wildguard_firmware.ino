/*
 * ============================================================================
 * WILDGUARD AI 3.0 — REAL-TIME AI WILDLIFE DETECTION & SMART CROP PROTECTION
 * ESP32 Microcontroller Firmware (esp32_wildguard_firmware.ino)
 * ============================================================================
 * Target Board : ESP32 DevKit V1 (ESP-WROOM-32, 3.3V CMOS Logic, Max 12mA/pin)
 * Serial Link  : 115200 bps 8N1 (Two-Way Framed JSON Protocol "WG3")
 *
 * MULTI-SENSOR ARCHITECTURE SUPPORTED:
 *   1. SENSOR_TF02_PRO_LIDAR (Default Outdoor Farm Sensor: 0.10m - 40.0m, IP65)
 *      - Connects via UART2 (RX2 = GPIO 16, TX2 = GPIO 17, 3.3V logic safe)
 *   2. SENSOR_LD2410_RADAR (24GHz FMCW Weatherproof Radar: 0.75m - 6.0m)
 *      - Connects via UART2 (RX2 = GPIO 16, TX2 = GPIO 17, 3.3V logic safe)
 *   3. SENSOR_JSN_SR04T (Waterproof Ultrasonic Sensor: 0.25m - 4.50m, IP66)
 *      - TRIG = GPIO 5, ECHO = GPIO 18 via 1kΩ + 2kΩ Voltage Divider (5V->3.33V)
 *   4. SENSOR_HCSR04_LAB (Indoor Laboratory Bench Sensor ONLY: 0.02m - 4.00m)
 *      - TRIG = GPIO 5, ECHO = GPIO 18 via 1kΩ + 2kΩ Voltage Divider (5V->3.33V)
 *      - STRICTLY CAPPED AT 400 cm (4.00 m). Never fabricates 15m readings!
 *
 * ACTUATOR & INDICATOR PINOUT:
 *   - GPIO 2   : Green Safe Monitoring LED (via 220Ω resistor to Common GND)
 *   - GPIO 19  : Red/Amber Wildlife Warning LED (via 220Ω resistor to Common GND)
 *   - GPIO 23  : Active Buzzer Module I/O (drives onboard NPN transistor base;
 *                Module VCC -> 5V rail, Module GND -> Common GND)
 *   - GPIO 21  : Blue IoT Transmission Status LED (via 220Ω resistor to GND)
 *   - GPIO 22  : Optional 5V Opto-Isolated Deterrent Strobe Relay (IN pin)
 * ============================================================================
 */

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>

// --------------------- GPIO PIN DEFINITIONS ---------------------
#define PIN_TRIG            5    // Ultrasonic Trigger Output (3.3V logic)
#define PIN_ECHO            18   // Ultrasonic Echo Input (MUST use 1kΩ+2kΩ divider!)
#define PIN_LIDAR_RX2       16   // TF02-Pro / TF-Luna LiDAR UART RX2 (3.3V logic)
#define PIN_LIDAR_TX2       17   // TF02-Pro / TF-Luna LiDAR UART TX2 (3.3V logic)
#define PIN_LED_MONITOR     2    // Green Monitoring Status LED
#define PIN_LED_WARNING     19   // Red/Amber Warning LED (via 220Ω resistor)
#define PIN_BUZZER          23   // Transistor-Buffered Active Buzzer Module I/O
#define PIN_LED_IOT         21   // Blue IoT Transmission LED (via 220Ω resistor)
#define PIN_RELAY_STROBE    22   // Optional Secondary Visual Strobe Relay

// --------------------- SENSOR MODEL ENUMERATION -----------------
enum SensorType {
  SENSOR_TF02_PRO_LIDAR = 0, // 0.10m - 40.0m Outdoor IP65 LiDAR
  SENSOR_JSN_SR04T      = 1, // 0.25m - 4.50m Outdoor Waterproof Ultrasonic
  SENSOR_HCSR04_LAB     = 2, // 0.02m - 4.00m Indoor Lab Demo Ultrasonic ONLY
  SENSOR_LD2410_RADAR   = 3  // 0.75m - 6.00m 24GHz FMCW Radar
};

SensorType activeSensor      = SENSOR_TF02_PRO_LIDAR;
String     activeSensorName  = "TF02_PRO_LIDAR";

// --------------------- CONFIGURABLE THRESHOLDS ------------------
float warningDistanceM       = 15.0f;
float criticalDistanceM      = 5.0f;
int   confirmThreshold       = 4;
float confidenceThreshold    = 0.70f;

// Animal Welfare & Hardware Safety Limits
unsigned long maxContinuousAlarmMs = 30000; // Auto-cutoff after 30s continuous sound
unsigned long alarmCooldownResetMs = 10000; // 10s pause after max continuous cutoff
unsigned long iotCooldownMs        = 15000; // Minimum 15s between duplicate IoT alerts

// --------------------- WI-FI & IOT ENDPOINT ---------------------
// Configured via Serial command or NVS (never hardcode private keys in frontend)
String wifiSsid              = "";
String wifiPassword          = "";
String iotWebhookUrl         = "";
String iotBearerToken        = "";

// --------------------- RUNTIME STATE VARIABLES ------------------
String currentClass          = "none"; // "elephant","wild_boar","deer","monkey","human","unsupported","none"
float  aiConfidence          = 0.0f;
int    consecutiveFrames     = 0;
bool   objectConfirmed       = false;

float  measuredDistanceCm    = -1.0f;
float  measuredDistanceM     = -1.0f;
bool   measurementValid      = false;
String sensorStatus          = "WAITING_FOR_SENSOR";

String systemState           = "NORMAL_MONITORING";
bool   alarmActive           = false;
bool   ledWarningActive      = false;
bool   manualAlarmOverride   = false;
bool   manualDeterrentDisable = false;
bool   ledEnabled            = true;
bool   soundEnabled          = true;

unsigned long alarmStartMs      = 0;
unsigned long cooldownStartMs   = 0;
bool          inSafetyCooldown  = false;
unsigned long lastIotSentMs     = 0;
unsigned long lastTelemetryMs   = 0;
unsigned long packetSeq         = 0;

// --------------------- PERSISTENT OFFLINE ALERT QUEUE -----------
struct QueuedAlert {
  String animal;
  float  distM;
  unsigned long timestampMs;
  bool   active;
};
#define MAX_OFFLINE_QUEUE 20
QueuedAlert offlineQueue[MAX_OFFLINE_QUEUE];
int pendingQueueCount = 0;

void enqueueOfflineAlert(String animal, float distM) {
  for (int i = 0; i < MAX_OFFLINE_QUEUE; i++) {
    if (!offlineQueue[i].active) {
      offlineQueue[i].animal = animal;
      offlineQueue[i].distM = distM;
      offlineQueue[i].timestampMs = millis();
      offlineQueue[i].active = true;
      pendingQueueCount++;
      return;
    }
  }
}

// --------------------- MULTI-SENSOR DISTANCE READING ------------
void readInstalledDistanceSensor() {
  if (activeSensor == SENSOR_TF02_PRO_LIDAR) {
    // Benewake TF02-Pro / TF-Luna 9-byte UART frame: [0x59, 0x59, Dist_L, Dist_H, Strength_L, Strength_H, ...]
    while (Serial2.available() >= 9) {
      if (Serial2.read() == 0x59 && Serial2.peek() == 0x59) {
        Serial2.read(); // consume second 0x59
        uint8_t distL = Serial2.read();
        uint8_t distH = Serial2.read();
        uint8_t strL  = Serial2.read();
        uint8_t strH  = Serial2.read();
        uint8_t tempL = Serial2.read();
        uint8_t tempH = Serial2.read();
        uint8_t chk   = Serial2.read();
        (void)strL; (void)strH; (void)tempL; (void)tempH; (void)chk;

        uint16_t rawCm = (uint16_t(distH) << 8) | distL;
        if (rawCm >= 10 && rawCm <= 4000) {
          measuredDistanceCm = (float)rawCm;
          measuredDistanceM  = measuredDistanceCm / 100.0f;
          measurementValid   = true;
          sensorStatus       = "VALID_MEASUREMENT";
        } else {
          measurementValid   = false;
          sensorStatus       = "OUT_OF_RANGE_MAX_40M";
        }
        return;
      }
    }
  } else {
    // Ultrasonic pulse timing for HC-SR04 (0.02-4.00m) or JSN-SR04T (0.25-4.50m)
    digitalWrite(PIN_TRIG, LOW);
    delayMicroseconds(2);
    digitalWrite(PIN_TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(PIN_TRIG, LOW);

    // 26000us timeout (~4.45m max physical acoustic propagation)
    long durationUs = pulseIn(PIN_ECHO, HIGH, 26000);
    if (durationUs <= 0) {
      measurementValid   = false;
      measuredDistanceCm = -1.0f;
      measuredDistanceM  = -1.0f;
      sensorStatus       = "INVALID_NO_ECHO";
      return;
    }

    float cm = (durationUs * 0.0343f) / 2.0f;
    float maxCm = (activeSensor == SENSOR_HCSR04_LAB) ? 400.0f : 450.0f;
    float minCm = (activeSensor == SENSOR_HCSR04_LAB) ? 2.0f   : 25.0f;

    if (cm < minCm) {
      measurementValid   = false;
      measuredDistanceCm = cm;
      measuredDistanceM  = cm / 100.0f;
      sensorStatus       = "BLIND_ZONE_FAULT";
    } else if (cm > maxCm) {
      // Strictly reject any reading above 4.00m on HC-SR04!
      measurementValid   = false;
      measuredDistanceCm = -1.0f;
      measuredDistanceM  = -1.0f;
      sensorStatus       = (activeSensor == SENSOR_HCSR04_LAB) ? "OUT_OF_RANGE_MAX_4.0M" : "OUT_OF_RANGE_MAX_4.5M";
    } else {
      measurementValid   = true;
      measuredDistanceCm = cm;
      measuredDistanceM  = cm / 100.0f;
      sensorStatus       = "VALID_MEASUREMENT";
    }
  }
}

// --------------------- IOT NOTIFICATION DISPATCHER --------------
String dispatchIotNotification(String animalName, float distM) {
  unsigned long now = millis();
  if (lastIotSentMs > 0 && (now - lastIotSentMs < iotCooldownMs)) {
    return "COOLDOWN_ACTIVE";
  }
  lastIotSentMs = now;
  digitalWrite(PIN_LED_IOT, HIGH);

  if (WiFi.status() == WL_CONNECTED && iotWebhookUrl.length() > 8) {
    HTTPClient http;
    http.begin(iotWebhookUrl);
    http.addHeader("Content-Type", "application/json");
    if (iotBearerToken.length() > 0) {
      http.addHeader("Authorization", "Bearer " + iotBearerToken);
    }
    String payload = "{\"proto\":\"WG3\",\"alert\":\"CRITICAL_ALERT\",\"animal\":\"" + animalName +
                     "\",\"distance_m\":" + String(distM, 2) +
                     ",\"sensor\":\"" + activeSensorName +
                     "\",\"message\":\"CRITICAL ALERT: " + animalName +
                     " inside critical crop zone (" + String(distM, 2) + "m).\"}";
    int httpCode = http.POST(payload);
    http.end();
    digitalWrite(PIN_LED_IOT, LOW);
    if (httpCode >= 200 && httpCode < 300) {
      return "DELIVERED";
    } else {
      enqueueOfflineAlert(animalName, distM);
      return "PENDING_HTTP_RETRY";
    }
  } else {
    enqueueOfflineAlert(animalName, distM);
    digitalWrite(PIN_LED_IOT, LOW);
    return "PENDING_OFFLINE";
  }
}

void flushOfflineQueueIfConnected() {
  if (WiFi.status() != WL_CONNECTED || iotWebhookUrl.length() <= 8 || pendingQueueCount == 0) {
    return;
  }
  for (int i = 0; i < MAX_OFFLINE_QUEUE; i++) {
    if (offlineQueue[i].active) {
      HTTPClient http;
      http.begin(iotWebhookUrl);
      http.addHeader("Content-Type", "application/json");
      String payload = "{\"proto\":\"WG3\",\"alert\":\"FLUSHED_OFFLINE_ALERT\",\"animal\":\"" +
                       offlineQueue[i].animal + "\",\"distance_m\":" + String(offlineQueue[i].distM, 2) + "}";
      int code = http.POST(payload);
      http.end();
      if (code >= 200 && code < 300) {
        offlineQueue[i].active = false;
        if (pendingQueueCount > 0) pendingQueueCount--;
      }
    }
  }
}

// --------------------- CLOSED-LOOP DECISION STATE MACHINE -------
void evaluateDecisionStateMachine() {
  bool isTargetWildlife = (currentClass == "elephant" || currentClass == "wild_boar" ||
                           currentClass == "boar"     || currentClass == "deer"      ||
                           currentClass == "monkey");
  bool isHuman          = (currentClass == "human" || currentClass == "person");
  bool isUnsupported    = (currentClass == "unsupported");

  if (manualDeterrentDisable) {
    systemState      = "SAFE_SHUTDOWN_OVERRIDE";
    alarmActive      = false;
    ledWarningActive = false;
    alarmStartMs     = 0;
  }
  else if (manualAlarmOverride) {
    systemState      = "MANUAL_ALARM_TEST";
    alarmActive      = soundEnabled;
    ledWarningActive = ledEnabled;
  }
  else if (isUnsupported) {
    // Unknown or non-target species (e.g. dog, sheep, bird) -> NEVER activate deterrent!
    systemState      = "UNSUPPORTED_SPECIES";
    alarmActive      = false;
    ledWarningActive = false;
    alarmStartMs     = 0;
  }
  else if (objectConfirmed && isHuman) {
    // Human safety rule: strictly suppress wildlife deterrent
    systemState      = "HUMAN_DETECTED";
    alarmActive      = false;
    ledWarningActive = false;
    alarmStartMs     = 0;
  }
  else if (objectConfirmed && isTargetWildlife) {
    if (!measurementValid) {
      systemState      = "SENSOR_OUT_OF_RANGE";
      alarmActive      = false;
      ledWarningActive = false;
      alarmStartMs     = 0;
    }
    else if (measuredDistanceM > warningDistanceM) {
      systemState      = "MONITORING";
      alarmActive      = false;
      ledWarningActive = false;
      alarmStartMs     = 0;
    }
    else {
      // Inside Warning or Critical Zone
      if (measuredDistanceM <= criticalDistanceM) {
        systemState = "CRITICAL_ALERT";
        dispatchIotNotification(currentClass, measuredDistanceM);
      } else {
        systemState = "WILDLIFE_WARNING";
      }

      // Enforce maximum continuous acoustic deterrent safety timer (30s max)
      unsigned long now = millis();
      if (alarmStartMs == 0) {
        alarmStartMs = now;
        inSafetyCooldown = false;
      }
      if (!inSafetyCooldown && (now - alarmStartMs > maxContinuousAlarmMs)) {
        inSafetyCooldown = true;
        cooldownStartMs  = now;
      }
      if (inSafetyCooldown && (now - cooldownStartMs > alarmCooldownResetMs)) {
        inSafetyCooldown = false;
        alarmStartMs     = now;
      }

      alarmActive      = soundEnabled && !inSafetyCooldown;
      ledWarningActive = ledEnabled;
    }
  }
  else {
    systemState      = "NORMAL_MONITORING";
    alarmActive      = false;
    ledWarningActive = false;
    alarmStartMs     = 0;
  }

  // Drive physical ESP32 GPIO pins
  digitalWrite(PIN_LED_MONITOR, (systemState == "NORMAL_MONITORING" || systemState == "MONITORING") ? HIGH : LOW);
  digitalWrite(PIN_LED_WARNING, ledWarningActive ? HIGH : LOW);
  digitalWrite(PIN_BUZZER,      alarmActive ? HIGH : LOW);
  digitalWrite(PIN_RELAY_STROBE, (systemState == "CRITICAL_ALERT" && ledWarningActive) ? HIGH : LOW);
}

// --------------------- TWO-WAY WG3 SERIAL PROTOCOL PARSER -------
String extractJsonString(const String& json, const String& key) {
  String pattern = "\"" + key + "\":\"";
  int start = json.indexOf(pattern);
  if (start < 0) return "";
  start += pattern.length();
  int end = json.indexOf("\"", start);
  if (end < 0) return "";
  return json.substring(start, end);
}

float extractJsonFloat(const String& json, const String& key, float fallback) {
  String pattern = "\"" + key + "\":";
  int start = json.indexOf(pattern);
  if (start < 0) return fallback;
  start += pattern.length();
  int end = start;
  while (end < (int)json.length() && (isDigit(json[end]) || json[end] == '.' || json[end] == '-')) {
    end++;
  }
  return json.substring(start, end).toFloat();
}

void sendAckPacket(const String& cmdName, const String& detail) {
  Serial.print("{\"proto\":\"WG3\",\"type\":\"ack\",\"cmd\":\"");
  Serial.print(cmdName);
  Serial.print("\",\"detail\":\"");
  Serial.print(detail);
  Serial.println("\"}");
}

void processSerialJsonFrame(String line) {
  line.trim();
  if (line.length() == 0) return;

  // Validate framing
  if (!line.startsWith("{") || !line.endsWith("}") || line.indexOf("\"proto\":\"WG3\"") < 0) {
    Serial.println("{\"proto\":\"WG3\",\"type\":\"error\",\"reason\":\"INVALID_WG3_FRAME\"}");
    return;
  }

  String cmd = extractJsonString(line, "cmd");
  if (cmd == "handshake" || cmd == "ping") {
    sendAckPacket(cmd, "ESP32_WILDGUARD_V3_ONLINE");
    return;
  }

  if (cmd == "ai_frame") {
    String cls = extractJsonString(line, "class");
    if (cls.length() > 0) currentClass = cls;
    aiConfidence      = extractJsonFloat(line, "conf", aiConfidence);
    consecutiveFrames = (int)extractJsonFloat(line, "frames", consecutiveFrames);
    warningDistanceM  = extractJsonFloat(line, "warn_m", warningDistanceM);
    criticalDistanceM = extractJsonFloat(line, "crit_m", criticalDistanceM);
    objectConfirmed   = (consecutiveFrames >= confirmThreshold) &&
                        (aiConfidence >= confidenceThreshold) &&
                        (currentClass != "none") &&
                        (currentClass != "unsupported");
    sendAckPacket("ai_frame", currentClass);
  }
  else if (cmd == "config") {
    String sensorStr = extractJsonString(line, "sensor");
    if (sensorStr == "HC_SR04_LAB") {
      activeSensor     = SENSOR_HCSR04_LAB;
      activeSensorName = "HC_SR04_LAB";
      if (warningDistanceM > 4.0f) warningDistanceM = 2.5f;
      if (criticalDistanceM > 3.5f) criticalDistanceM = 1.0f;
    } else if (sensorStr == "JSN_SR04T_ULTRASONIC") {
      activeSensor     = SENSOR_JSN_SR04T;
      activeSensorName = "JSN_SR04T_ULTRASONIC";
      if (warningDistanceM > 4.5f) warningDistanceM = 3.5f;
      if (criticalDistanceM > 4.0f) criticalDistanceM = 1.5f;
    } else if (sensorStr == "HLK_LD2410_RADAR") {
      activeSensor     = SENSOR_LD2410_RADAR;
      activeSensorName = "HLK_LD2410_RADAR";
      if (warningDistanceM > 6.0f) warningDistanceM = 5.0f;
      if (criticalDistanceM > 5.0f) criticalDistanceM = 2.5f;
    } else if (sensorStr == "TF02_PRO_LIDAR") {
      activeSensor     = SENSOR_TF02_PRO_LIDAR;
      activeSensorName = "TF02_PRO_LIDAR";
    }
    warningDistanceM  = extractJsonFloat(line, "warn_m", warningDistanceM);
    criticalDistanceM = extractJsonFloat(line, "crit_m", criticalDistanceM);
    sendAckPacket("config", activeSensorName);
  }
  else if (cmd == "override") {
    if (line.indexOf("\"manual_alarm\":true") >= 0) manualAlarmOverride = true;
    if (line.indexOf("\"manual_alarm\":false") >= 0) manualAlarmOverride = false;
    if (line.indexOf("\"disable_deterrent\":true") >= 0) manualDeterrentDisable = true;
    if (line.indexOf("\"disable_deterrent\":false") >= 0) manualDeterrentDisable = false;
    sendAckPacket("override", manualDeterrentDisable ? "SAFE_SHUTDOWN" : "NORMAL");
  }
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, PIN_LIDAR_RX2, PIN_LIDAR_TX2);

  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_LED_MONITOR, OUTPUT);
  pinMode(PIN_LED_WARNING, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_LED_IOT, OUTPUT);
  pinMode(PIN_RELAY_STROBE, OUTPUT);

  digitalWrite(PIN_LED_MONITOR, HIGH);
  digitalWrite(PIN_LED_WARNING, LOW);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_LED_IOT, LOW);
  digitalWrite(PIN_RELAY_STROBE, LOW);

  for (int i = 0; i < MAX_OFFLINE_QUEUE; i++) {
    offlineQueue[i].active = false;
  }

  Serial.println("{\"proto\":\"WG3\",\"type\":\"boot\",\"fw\":\"3.0.0\",\"board\":\"ESP32_DEVKIT_V1\"}");
}

void loop() {
  while (Serial.available() > 0) {
    String line = Serial.readStringUntil('\n');
    processSerialJsonFrame(line);
  }

  readInstalledDistanceSensor();
  evaluateDecisionStateMachine();
  flushOfflineQueueIfConnected();

  // Emit 10Hz verified hardware telemetry packet
  unsigned long now = millis();
  if (now - lastTelemetryMs >= 100) {
    lastTelemetryMs = now;
    packetSeq++;
    Serial.print("{\"proto\":\"WG3\",\"type\":\"telemetry\",\"seq\":");
    Serial.print(packetSeq);
    Serial.print(",\"source\":\"REAL_HARDWARE\",\"sensor\":\"");
    Serial.print(activeSensorName);
    Serial.print("\",\"sensor_status\":\"");
    Serial.print(sensorStatus);
    Serial.print("\",\"valid_dist\":");
    Serial.print(measurementValid ? "true" : "false");
    Serial.print(",\"dist_cm\":");
    Serial.print(measuredDistanceCm, 1);
    Serial.print(",\"dist_m\":");
    Serial.print(measuredDistanceM, 2);
    Serial.print(",\"state\":\"");
    Serial.print(systemState);
    Serial.print("\",\"class\":\"");
    Serial.print(currentClass);
    Serial.print("\",\"conf\":");
    Serial.print(aiConfidence, 2);
    Serial.print(",\"frames\":");
    Serial.print(consecutiveFrames);
    Serial.print(",\"confirmed\":");
    Serial.print(objectConfirmed ? "true" : "false");
    Serial.print(",\"alarm\":");
    Serial.print(alarmActive ? "true" : "false");
    Serial.print(",\"led\":");
    Serial.print(ledWarningActive ? "true" : "false");
    Serial.print(",\"queue\":");
    Serial.print(pendingQueueCount);
    Serial.println("}");
  }
}
