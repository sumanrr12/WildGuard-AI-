#!/usr/bin/env python3
"""
================================================================================
WILDGUARD AI 3.0 — REAL-TIME AI WILDLIFE DETECTION, IOT NOTIFICATION GATEWAY,
PERSISTENT SQLITE STORAGE & ESP32 SERIAL BRIDGE
================================================================================
File        : python_ai_bridge/wildguard_ai_serial_bridge.py
Version     : 3.0.0
Architecture:
  1. Real USB Webcam / RTSP Video Capture (OpenCV cv2.VideoCapture)
  2. Real Ultralytics YOLOv8/v11 Inference Engine + Custom Model Loader (.pt/.onnx)
  3. Strict Wildlife Class Mapping Engine (NO false proxy mappings: dogs are NEVER
     mapped to monkeys, sheep are NEVER mapped to deer, bears are NEVER mapped to
     wild boars; unsupported classes are explicitly flagged as UNSUPPORTED_SPECIES)
  4. Temporal Consecutive-Frame Confirmation & False-Positive BBox Filter
  5. Multi-Sensor Range & Validity Verifier (TF02-Pro LiDAR, LD2410 Radar,
     JSN-SR04T Waterproof Ultrasonic, HC-SR04 Lab-Only 0.02m–4.00m limit)
  6. Genuine Two-Way ESP32 Serial Protocol (WG3 JSON Protocol @ 115200 bps)
  7. Persistent SQLite Database (detections, alerts, offline_queue, config, tests)
  8. Real Configurable IoT Notification Service (HTTP Webhook / Twilio SMS /
     Telegram API) with Honest Delivery Verification & Offline Retry Queue
  9. Local HTTP Bridge Server (http://127.0.0.1:8765) for Browser Frontend Sync
================================================================================
"""

from __future__ import annotations

import argparse
import csv
import datetime
import io
import json
import logging
import os
import sqlite3
import sys
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field, asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, List, Optional, Tuple

# Optional runtime dependencies (gracefully probed and reported)
try:
    import cv2  # type: ignore
    HAS_OPENCV = True
except ImportError:
    cv2 = None
    HAS_OPENCV = False

try:
    import numpy as np  # type: ignore
    HAS_NUMPY = True
except ImportError:
    np = None
    HAS_NUMPY = False

try:
    import serial  # type: ignore
    import serial.tools.list_ports  # type: ignore
    HAS_PYSERIAL = True
except ImportError:
    serial = None
    HAS_PYSERIAL = False

try:
    from ultralytics import YOLO  # type: ignore
    HAS_ULTRALYTICS = True
except ImportError:
    YOLO = None
    HAS_ULTRALYTICS = False


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("WildGuardAI3")


# ==============================================================================
# 1. SENSOR ENGINEERING SPECIFICATIONS & RANGE VALIDATION
# ==============================================================================
SENSOR_CATALOG: Dict[str, Dict[str, Any]] = {
    "TF02_PRO_LIDAR": {
        "name": "Benewake TF02-Pro IP65 Outdoor ToF LiDAR",
        "interface": "UART (3.3V LVTTL, 115200 bps)",
        "min_range_m": 0.10,
        "max_range_m": 40.00,
        "default_warn_m": 15.0,
        "default_crit_m": 5.0,
        "accuracy_cm": 5.0,
        "outdoor_rated": True,
        "limitations": "Heavy dense fog or mud directly coating optical window can attenuate IR beam.",
    },
    "TF_LUNA_LIDAR": {
        "name": "Benewake TF-Luna Short/Mid-Range LiDAR",
        "interface": "UART / I2C (3.3V logic)",
        "min_range_m": 0.20,
        "max_range_m": 8.00,
        "default_warn_m": 6.5,
        "default_crit_m": 3.0,
        "accuracy_cm": 2.0,
        "outdoor_rated": False,
        "limitations": "8m maximum range; requires IP65 acrylic window housing for outdoor farm use.",
    },
    "HLK_LD2410_RADAR": {
        "name": "HLK-LD2410 24GHz FMCW Millimeter-Wave Radar",
        "interface": "UART (3.3V logic, 256000 bps)",
        "min_range_m": 0.75,
        "max_range_m": 6.00,
        "default_warn_m": 5.0,
        "default_crit_m": 2.5,
        "accuracy_cm": 15.0,
        "outdoor_rated": True,
        "limitations": "6m range; immune to rain, fog, dust, and darkness, but wider beam angle (60 deg).",
    },
    "JSN_SR04T_ULTRASONIC": {
        "name": "JSN-SR04T Waterproof Ultrasonic Distance Sensor",
        "interface": "TRIG/ECHO (5V supply -> 1k/2k divider to 3.3V GPIO)",
        "min_range_m": 0.25,
        "max_range_m": 4.50,
        "default_warn_m": 3.5,
        "default_crit_m": 1.5,
        "accuracy_cm": 1.5,
        "outdoor_rated": True,
        "limitations": "4.5m max range; 25cm blind zone; soft animal fur absorbs acoustic energy beyond 4m.",
    },
    "HC_SR04_LAB": {
        "name": "HC-SR04 Ultrasonic Sensor (Laboratory Bench Demo Only)",
        "interface": "TRIG (GPIO 5) / ECHO (GPIO 18 via 1kΩ+2kΩ 5V->3.3V Divider)",
        "min_range_m": 0.02,
        "max_range_m": 4.00,
        "default_warn_m": 2.5,
        "default_crit_m": 1.0,
        "accuracy_cm": 0.3,
        "outdoor_rated": False,
        "limitations": "STRICTLY 0.02m–4.00m indoor bench range. Cannot measure 15m! Exposed transducers fail in rain/condensation.",
    },
}


def validate_sensor_measurement(sensor_id: str, distance_m: float) -> Tuple[bool, str, float]:
    """
    Validates whether a measured distance is physically within the installed
    sensor's operating range. Never allows HC-SR04 to report 15m!
    """
    spec = SENSOR_CATALOG.get(sensor_id, SENSOR_CATALOG["TF02_PRO_LIDAR"])
    if distance_m is None or distance_m < 0:
        return False, "INVALID_NO_ECHO", -1.0
    if distance_m < spec["min_range_m"]:
        return False, f"BLIND_ZONE_BELOW_{spec['min_range_m']}M", distance_m
    if distance_m > spec["max_range_m"]:
        return False, f"OUT_OF_RANGE_MAX_{spec['max_range_m']}M", -1.0
    return True, "VALID_MEASUREMENT", round(distance_m, 3)


# ==============================================================================
# 2. STRICT WILDLIFE CLASS MAPPING & TEMPORAL CONFIRMATION ENGINE
# ==============================================================================
# Canonical supported classes in WildGuard AI 3.0:
#   Wildlife targets (activate warning/critical alarms):
#     - elephant
#     - wild_boar
#     - deer
#     - monkey
#   Human safety class (strictly suppresses wildlife alarm, records silent log):
#     - human
#
# CRITICAL RULE: Never map dog -> monkey, sheep -> deer, or bear -> wild_boar!
DEFAULT_EXACT_CLASS_MAP: Dict[str, str] = {
    # Exact species names from custom wildlife YOLO models or standard COCO
    "elephant": "elephant",
    "asian_elephant": "elephant",
    "african_elephant": "elephant",
    "wild_boar": "wild_boar",
    "wild boar": "wild_boar",
    "boar": "wild_boar",
    "sus_scrofa": "wild_boar",
    "deer": "deer",
    "chital": "deer",
    "sambar": "deer",
    "spotted_deer": "deer",
    "cervus": "deer",
    "monkey": "monkey",
    "macaque": "monkey",
    "rhesus_macaque": "monkey",
    "langur": "monkey",
    "primate": "monkey",
    "person": "human",
    "human": "human",
    "farmer": "human",
}

TARGET_WILDLIFE_CLASSES = {"elephant", "wild_boar", "deer", "monkey"}
FORBIDDEN_PROXY_CLASSES = {"dog", "sheep", "bear", "cow", "horse", "cat", "bird", "zebra", "giraffe"}


@dataclass
class DetectionConfirmationResult:
    raw_label: str
    mapped_class: str  # 'elephant', 'wild_boar', 'deer', 'monkey', 'human', 'unsupported', 'none'
    category: str      # 'WILDLIFE_TARGET', 'HUMAN_SAFE', 'UNSUPPORTED_SPECIES', 'NONE'
    confidence: float
    bbox: List[int]    # [x1, y1, x2, y2]
    consecutive_frames: int
    required_frames: int
    confirmed: bool
    rejected_reason: Optional[str]
    timestamp: str


class WildlifeClassifierFilter:
    """
    Handles strict species classification, custom class map loading, confidence
    thresholding, bounding-box area filtering, and consecutive-frame confirmation.
    """

    def __init__(
        self,
        conf_threshold: float = 0.70,
        confirm_frames: int = 4,
        min_bbox_area_px: int = 900,
        custom_map_path: Optional[str] = None,
    ) -> None:
        self.conf_threshold = conf_threshold
        self.confirm_frames = max(1, confirm_frames)
        self.min_bbox_area_px = min_bbox_area_px
        self.class_map: Dict[str, str] = dict(DEFAULT_EXACT_CLASS_MAP)
        if custom_map_path and os.path.exists(custom_map_path):
            self.load_custom_class_map(custom_map_path)

        self.active_class: str = "none"
        self.consecutive_count: int = 0
        self.missed_frames: int = 0

    def load_custom_class_map(self, path: str) -> None:
        with open(path, "r", encoding="utf-8") as f:
            user_map = json.load(f)
        for raw_k, target_v in user_map.items():
            norm_k = str(raw_k).strip().lower()
            norm_v = str(target_v).strip().lower()
            if norm_k in FORBIDDEN_PROXY_CLASSES and norm_v in TARGET_WILDLIFE_CLASSES:
                raise ValueError(
                    f"Safety violation: Proxy mapping '{norm_k}' -> '{norm_v}' is strictly forbidden in WildGuard AI 3.0."
                )
            self.class_map[norm_k] = norm_v

    def inspect_model_classes(self, model_names: Dict[int, str]) -> Dict[str, Any]:
        """
        Audits the loaded YOLO model's class dictionary and reports which of the
        5 required classes (elephant, wild_boar, deer, monkey, human) are supported
        and which are missing.
        """
        available_targets = set()
        raw_values = [str(v).strip().lower() for v in model_names.values()]
        for raw_name in raw_values:
            mapped = self.class_map.get(raw_name)
            if mapped:
                available_targets.add(mapped)

        required_all = {"elephant", "wild_boar", "deer", "monkey", "human"}
        missing = sorted(required_all - available_targets)
        return {
            "total_model_classes": len(model_names),
            "supported_wildguard_classes": sorted(available_targets),
            "unsupported_required_classes": missing,
            "is_standard_coco_only": missing == ["deer", "monkey", "wild_boar"],
            "limitation_notice": (
                "Standard COCO model detected: natively supports 'elephant' and 'person' (human), "
                "but does NOT include trained classes for 'wild_boar', 'deer', or 'monkey'. "
                "Load a custom wildlife-trained YOLO model (--model wildguard_wildlife.pt) for full 5-species support."
                if missing
                else "Full 5-class wildlife & human safety model verified."
            ),
        }

    def process_frame_detections(
        self,
        detections: List[Dict[str, Any]],
    ) -> DetectionConfirmationResult:
        """
        Processes raw detections from a single camera frame:
        Each item in `detections` has: {'label': str, 'conf': float, 'bbox': [x1, y1, x2, y2]}
        """
        now_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        if not detections:
            self.missed_frames += 1
            if self.missed_frames >= 2:
                self.consecutive_count = 0
                self.active_class = "none"
            return DetectionConfirmationResult(
                raw_label="none",
                mapped_class="none",
                category="NONE",
                confidence=0.0,
                bbox=[0, 0, 0, 0],
                consecutive_frames=self.consecutive_count,
                required_frames=self.confirm_frames,
                confirmed=False,
                rejected_reason=None,
                timestamp=now_ts,
            )

        # Sort by highest confidence first
        best = sorted(detections, key=lambda d: float(d.get("conf", 0.0)), reverse=True)[0]
        raw_label = str(best.get("label", "unknown")).strip().lower()
        conf = float(best.get("conf", 0.0))
        bbox = list(best.get("bbox", [0, 0, 100, 100]))
        area = max(0, (bbox[2] - bbox[0]) * (bbox[3] - bbox[1]))

        mapped = self.class_map.get(raw_label, "unsupported")

        # 1. Check if species is unsupported (e.g. dog, sheep, bear, bird, car)
        if mapped == "unsupported":
            self.consecutive_count = 0
            self.active_class = "unsupported"
            return DetectionConfirmationResult(
                raw_label=raw_label,
                mapped_class="unsupported",
                category="UNSUPPORTED_SPECIES",
                confidence=round(conf, 4),
                bbox=bbox,
                consecutive_frames=0,
                required_frames=self.confirm_frames,
                confirmed=False,
                rejected_reason=f"Class '{raw_label}' is not a target wildlife species; deterrent suppressed.",
                timestamp=now_ts,
            )

        # 2. Check bounding box minimum area (false positive noise rejection)
        if area < self.min_bbox_area_px:
            self.missed_frames += 1
            if self.missed_frames >= 2:
                self.consecutive_count = 0
            return DetectionConfirmationResult(
                raw_label=raw_label,
                mapped_class=mapped,
                category="HUMAN_SAFE" if mapped == "human" else "WILDLIFE_TARGET",
                confidence=round(conf, 4),
                bbox=bbox,
                consecutive_frames=self.consecutive_count,
                required_frames=self.confirm_frames,
                confirmed=False,
                rejected_reason=f"Bounding box area ({area}px²) below minimum noise threshold ({self.min_bbox_area_px}px²).",
                timestamp=now_ts,
            )

        # 3. Check confidence threshold
        if conf < self.conf_threshold:
            self.missed_frames += 1
            if self.missed_frames >= 2:
                self.consecutive_count = 0
            return DetectionConfirmationResult(
                raw_label=raw_label,
                mapped_class=mapped,
                category="HUMAN_SAFE" if mapped == "human" else "WILDLIFE_TARGET",
                confidence=round(conf, 4),
                bbox=bbox,
                consecutive_frames=self.consecutive_count,
                required_frames=self.confirm_frames,
                confirmed=False,
                rejected_reason=f"Confidence {conf*100:.1f}% below threshold {self.conf_threshold*100:.1f}%.",
                timestamp=now_ts,
            )

        # 4. Valid detection above threshold -> update consecutive frame counter
        self.missed_frames = 0
        if self.active_class == mapped:
            self.consecutive_count += 1
        else:
            self.active_class = mapped
            self.consecutive_count = 1

        is_confirmed = self.consecutive_count >= self.confirm_frames
        category = "HUMAN_SAFE" if mapped == "human" else "WILDLIFE_TARGET"

        return DetectionConfirmationResult(
            raw_label=raw_label,
            mapped_class=mapped,
            category=category,
            confidence=round(conf, 4),
            bbox=bbox,
            consecutive_frames=self.consecutive_count,
            required_frames=self.confirm_frames,
            confirmed=is_confirmed,
            rejected_reason=None if is_confirmed else f"Awaiting temporal confirmation ({self.consecutive_count}/{self.confirm_frames} frames).",
            timestamp=now_ts,
        )


# ==============================================================================
# 3. PERSISTENT SQLITE DATABASE MANAGER
# ==============================================================================
class WildGuardDatabase:
    """
    Persistent SQLite database storing detection logs, alert history, offline
    notification queue, device settings, and automated test results.
    """

    def __init__(self, db_path: str = "wildguard_data.db") -> None:
        self.db_path = db_path
        self._lock = threading.Lock()
        self._persistent_conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._persistent_conn.row_factory = sqlite3.Row
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        return self._persistent_conn

    def _init_schema(self) -> None:
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS detections (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    source_mode TEXT NOT NULL,
                    raw_label TEXT NOT NULL,
                    mapped_class TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    consecutive_frames INTEGER NOT NULL,
                    confirmed INTEGER NOT NULL,
                    sensor_id TEXT NOT NULL,
                    distance_m REAL,
                    system_state TEXT NOT NULL,
                    alarm_active INTEGER NOT NULL,
                    notes TEXT
                );

                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    animal TEXT NOT NULL,
                    distance_m REAL NOT NULL,
                    severity TEXT NOT NULL,
                    message TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    status TEXT NOT NULL,
                    http_code INTEGER,
                    retry_count INTEGER DEFAULT 0,
                    delivered_at TEXT,
                    error_detail TEXT
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS test_results (
                    test_id INTEGER PRIMARY KEY,
                    scenario_name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    inputs_json TEXT NOT NULL,
                    transitions_json TEXT NOT NULL,
                    expected_summary TEXT NOT NULL,
                    actual_summary TEXT NOT NULL,
                    passed INTEGER NOT NULL,
                    failure_reason TEXT,
                    executed_at TEXT NOT NULL
                );
                """
            )
            conn.commit()

    def record_detection(self, rec: Dict[str, Any]) -> int:
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO detections (
                    timestamp, source_mode, raw_label, mapped_class, confidence,
                    consecutive_frames, confirmed, sensor_id, distance_m,
                    system_state, alarm_active, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rec.get("timestamp", datetime.datetime.now().isoformat()),
                    rec.get("source_mode", "REAL_HARDWARE"),
                    rec.get("raw_label", "none"),
                    rec.get("mapped_class", "none"),
                    float(rec.get("confidence", 0.0)),
                    int(rec.get("consecutive_frames", 0)),
                    1 if rec.get("confirmed") else 0,
                    rec.get("sensor_id", "TF02_PRO_LIDAR"),
                    rec.get("distance_m"),
                    rec.get("system_state", "NORMAL_MONITORING"),
                    1 if rec.get("alarm_active") else 0,
                    rec.get("notes", ""),
                ),
            )
            conn.commit()
            return int(cur.lastrowid or 0)

    def enqueue_or_record_notification(self, notif: Dict[str, Any]) -> int:
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO notifications (
                    timestamp, animal, distance_m, severity, message,
                    provider, status, http_code, retry_count, delivered_at, error_detail
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    notif["timestamp"],
                    notif["animal"],
                    float(notif["distance_m"]),
                    notif.get("severity", "CRITICAL"),
                    notif["message"],
                    notif.get("provider", "WEBHOOK"),
                    notif["status"],  # 'DELIVERED', 'PENDING', 'FAILED', 'UNCONFIGURED'
                    notif.get("http_code"),
                    int(notif.get("retry_count", 0)),
                    notif.get("delivered_at"),
                    notif.get("error_detail"),
                ),
            )
            conn.commit()
            return int(cur.lastrowid or 0)

    def update_notification_status(
        self,
        notif_id: int,
        status: str,
        http_code: Optional[int] = None,
        delivered_at: Optional[str] = None,
        error_detail: Optional[str] = None,
        increment_retry: bool = False,
    ) -> None:
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                UPDATE notifications
                SET status = ?,
                    http_code = COALESCE(?, http_code),
                    delivered_at = COALESCE(?, delivered_at),
                    error_detail = ?,
                    retry_count = retry_count + ?
                WHERE id = ?
                """,
                (status, http_code, delivered_at, error_detail, 1 if increment_retry else 0, notif_id),
            )
            conn.commit()

    def get_pending_notifications(self) -> List[Dict[str, Any]]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM notifications WHERE status = 'PENDING' ORDER BY id ASC"
            ).fetchall()
            return [dict(r) for r in rows]

    def get_recent_detections(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM detections ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def get_recent_notifications(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM notifications ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(r) for r in rows]

    def export_detections_csv(self, output_csv_path: str) -> str:
        rows = self.get_recent_detections(limit=5000)
        with open(output_csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "ID", "Timestamp", "Source Mode", "Raw Label", "Mapped Class",
                "Confidence", "Consecutive Frames", "Confirmed", "Sensor ID",
                "Distance (m)", "System State", "Alarm Active", "Notes"
            ])
            for r in rows:
                writer.writerow([
                    r["id"], r["timestamp"], r["source_mode"], r["raw_label"],
                    r["mapped_class"], r["confidence"], r["consecutive_frames"],
                    bool(r["confirmed"]), r["sensor_id"], r["distance_m"],
                    r["system_state"], bool(r["alarm_active"]), r["notes"]
                ])
        return output_csv_path


# ==============================================================================
# 4. REAL CONFIGURABLE IOT NOTIFICATION DISPATCHER (WITH OFFLINE QUEUE & RETRY)
# ==============================================================================
class NotificationDispatcher:
    """
    Sends critical crop intrusion alerts through a real configured HTTP Webhook,
    Twilio SMS, or Telegram Bot endpoint.
    NEVER claims a message was DELIVERED unless the provider confirms HTTP 2xx.
    When offline or unconfigured, stores alerts in SQLite with PENDING status.
    """

    def __init__(
        self,
        db: WildGuardDatabase,
        webhook_url: Optional[str] = None,
        auth_token: Optional[str] = None,
        farmer_phone: Optional[str] = None,
        cooldown_sec: float = 15.0,
    ) -> None:
        self.db = db
        self.webhook_url = webhook_url or os.environ.get("WILDGUARD_WEBHOOK_URL", "")
        self.auth_token = auth_token or os.environ.get("WILDGUARD_API_TOKEN", "")
        self.farmer_phone = farmer_phone or os.environ.get("WILDGUARD_FARMER_PHONE", "")
        self.cooldown_sec = cooldown_sec
        self.network_simulated_online = True
        self._last_sent_by_species: Dict[str, float] = {}

    def send_critical_alert(
        self,
        animal: str,
        distance_m: float,
        sensor_id: str = "TF02_PRO_LIDAR",
    ) -> Dict[str, Any]:
        now = time.time()
        now_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Duplicate alert cooldown check
        last_t = self._last_sent_by_species.get(animal, 0.0)
        if (now - last_t) < self.cooldown_sec:
            return {
                "status": "COOLDOWN_SUPPRESSED",
                "animal": animal,
                "distance_m": distance_m,
                "timestamp": now_ts,
                "detail": f"Duplicate alert suppressed (cooldown {self.cooldown_sec}s active).",
            }

        self._last_sent_by_species[animal] = now
        message = (
            f"WILDGUARD AI CRITICAL ALERT: Confirmed {animal.upper()} inside Critical Crop "
            f"Zone at {distance_m:.2f}m (Sensor: {sensor_id}). Immediate attention required."
        )

        # If network is offline, immediately queue in SQLite as PENDING
        if not self.network_simulated_online:
            notif_id = self.db.enqueue_or_record_notification({
                "timestamp": now_ts,
                "animal": animal,
                "distance_m": distance_m,
                "severity": "CRITICAL",
                "message": message,
                "provider": "OFFLINE_QUEUE",
                "status": "PENDING",
                "http_code": None,
                "retry_count": 0,
                "delivered_at": None,
                "error_detail": "Network disconnected; queued in persistent offline storage.",
            })
            return {
                "id": notif_id,
                "status": "PENDING",
                "animal": animal,
                "distance_m": distance_m,
                "timestamp": now_ts,
                "message": message,
                "detail": "Network offline. Alert persistently queued as PENDING.",
            }

        # If no external webhook URL is configured, record honestly as PENDING / UNCONFIGURED_ENDPOINT
        if not self.webhook_url.strip():
            notif_id = self.db.enqueue_or_record_notification({
                "timestamp": now_ts,
                "animal": animal,
                "distance_m": distance_m,
                "severity": "CRITICAL",
                "message": message,
                "provider": "UNCONFIGURED",
                "status": "PENDING",
                "http_code": None,
                "retry_count": 0,
                "delivered_at": None,
                "error_detail": "No external SMS/Webhook URL configured yet. Stored in local queue.",
            })
            return {
                "id": notif_id,
                "status": "PENDING",
                "animal": animal,
                "distance_m": distance_m,
                "timestamp": now_ts,
                "message": message,
                "detail": "No SMS/Webhook endpoint configured; stored as PENDING.",
            }

        # Perform actual HTTP POST to the configured endpoint
        payload = json.dumps({
            "event": "CRITICAL_CROP_INTRUSION",
            "animal": animal,
            "distance_m": round(distance_m, 2),
            "sensor_id": sensor_id,
            "farmer_phone": self.farmer_phone,
            "message": message,
            "timestamp": now_ts,
        }).encode("utf-8")

        headers = {"Content-Type": "application/json", "User-Agent": "WildGuardAI/3.0"}
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        req = urllib.request.Request(self.webhook_url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5.0) as resp:
                http_code = resp.getcode()
                if 200 <= http_code < 300:
                    notif_id = self.db.enqueue_or_record_notification({
                        "timestamp": now_ts,
                        "animal": animal,
                        "distance_m": distance_m,
                        "severity": "CRITICAL",
                        "message": message,
                        "provider": self.webhook_url,
                        "status": "DELIVERED",
                        "http_code": http_code,
                        "retry_count": 0,
                        "delivered_at": now_ts,
                        "error_detail": None,
                    })
                    return {
                        "id": notif_id,
                        "status": "DELIVERED",
                        "http_code": http_code,
                        "animal": animal,
                        "distance_m": distance_m,
                        "timestamp": now_ts,
                        "message": message,
                    }
                else:
                    raise RuntimeError(f"Unexpected HTTP status {http_code}")
        except Exception as exc:
            notif_id = self.db.enqueue_or_record_notification({
                "timestamp": now_ts,
                "animal": animal,
                "distance_m": distance_m,
                "severity": "CRITICAL",
                "message": message,
                "provider": self.webhook_url,
                "status": "PENDING",
                "http_code": None,
                "retry_count": 1,
                "delivered_at": None,
                "error_detail": str(exc),
            })
            return {
                "id": notif_id,
                "status": "PENDING",
                "animal": animal,
                "distance_m": distance_m,
                "timestamp": now_ts,
                "message": message,
                "detail": f"Delivery failed ({exc}); queued as PENDING for automatic retry.",
            }

    def retry_pending_queue(self) -> List[Dict[str, Any]]:
        """Retries all PENDING notifications when connectivity is available."""
        if not self.network_simulated_online or not self.webhook_url.strip():
            return []
        results = []
        for item in self.db.get_pending_notifications():
            now_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            payload = json.dumps({
                "event": "CRITICAL_CROP_INTRUSION_RETRY",
                "animal": item["animal"],
                "distance_m": item["distance_m"],
                "message": item["message"],
                "original_timestamp": item["timestamp"],
                "retry_timestamp": now_ts,
            }).encode("utf-8")
            headers = {"Content-Type": "application/json", "User-Agent": "WildGuardAI/3.0"}
            if self.auth_token:
                headers["Authorization"] = f"Bearer {self.auth_token}"
            req = urllib.request.Request(self.webhook_url, data=payload, headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=5.0) as resp:
                    code = resp.getcode()
                    if 200 <= code < 300:
                        self.db.update_notification_status(
                            item["id"], "DELIVERED", http_code=code, delivered_at=now_ts, error_detail=None
                        )
                        results.append({"id": item["id"], "status": "DELIVERED", "http_code": code})
                    else:
                        self.db.update_notification_status(
                            item["id"], "PENDING", http_code=code, error_detail=f"HTTP {code}", increment_retry=True
                        )
            except Exception as exc:
                self.db.update_notification_status(
                    item["id"], "PENDING", error_detail=str(exc), increment_retry=True
                )
        return results


# ==============================================================================
# 5. CLOSED-LOOP WILDLIFE PROTECTION STATE MACHINE ENGINE
# ==============================================================================
class WildGuardStateMachine:
    """
    Genuine closed-loop decision engine used by both the Python bridge and the
    10-scenario automated test suite.
    """

    def __init__(
        self,
        sensor_id: str = "TF02_PRO_LIDAR",
        warning_dist_m: Optional[float] = None,
        critical_dist_m: Optional[float] = None,
        conf_threshold: float = 0.70,
        confirm_frames: int = 4,
        max_continuous_alarm_sec: float = 30.0,
        db: Optional[WildGuardDatabase] = None,
        notifier: Optional[NotificationDispatcher] = None,
    ) -> None:
        self.sensor_id = sensor_id if sensor_id in SENSOR_CATALOG else "TF02_PRO_LIDAR"
        spec = SENSOR_CATALOG[self.sensor_id]
        self.warning_dist_m = min(
            warning_dist_m if warning_dist_m is not None else spec["default_warn_m"],
            spec["max_range_m"],
        )
        self.critical_dist_m = min(
            critical_dist_m if critical_dist_m is not None else spec["default_crit_m"],
            self.warning_dist_m - 0.5,
        )
        self.classifier = WildlifeClassifierFilter(
            conf_threshold=conf_threshold,
            confirm_frames=confirm_frames,
        )
        self.max_continuous_alarm_sec = max_continuous_alarm_sec
        self.db = db or WildGuardDatabase(":memory:")
        self.notifier = notifier or NotificationDispatcher(self.db)

        # Runtime state
        self.state: str = "NORMAL_MONITORING"
        self.alarm_active: bool = False
        self.led_warning_active: bool = False
        self.manual_deterrent_disabled: bool = False
        self.manual_alarm_override: bool = False
        self.continuous_alarm_sec: float = 0.0
        self.last_valid_distance_m: Optional[float] = None
        self.sensor_status: str = "READY"

    def evaluate_step(
        self,
        detections: List[Dict[str, Any]],
        raw_distance_m: float,
        dt_sec: float = 0.1,
    ) -> Dict[str, Any]:
        det_res = self.classifier.process_frame_detections(detections)
        valid_dist, dist_status, checked_dist_m = validate_sensor_measurement(
            self.sensor_id, raw_distance_m
        )
        self.sensor_status = dist_status
        self.last_valid_distance_m = checked_dist_m if valid_dist else None

        notification_outcome = None

        if self.manual_deterrent_disabled:
            self.state = "SAFE_SHUTDOWN_OVERRIDE"
            self.alarm_active = False
            self.led_warning_active = False
            self.continuous_alarm_sec = 0.0
        elif self.manual_alarm_override:
            self.state = "MANUAL_ALARM_TEST"
            self.alarm_active = True
            self.led_warning_active = True
            self.continuous_alarm_sec += dt_sec
        elif det_res.mapped_class == "unsupported":
            self.state = "UNSUPPORTED_SPECIES"
            self.alarm_active = False
            self.led_warning_active = False
            self.continuous_alarm_sec = 0.0
        elif det_res.confirmed and det_res.mapped_class == "human":
            # Human safety state: strictly suppress wildlife alarm and log silent record
            self.state = "HUMAN_DETECTED"
            self.alarm_active = False
            self.led_warning_active = False
            self.continuous_alarm_sec = 0.0
        elif det_res.confirmed and det_res.mapped_class in TARGET_WILDLIFE_CLASSES:
            if not valid_dist:
                # Sensor out of range or fault
                self.state = "MONITORING_SENSOR_OUT_OF_RANGE"
                self.alarm_active = False
                self.led_warning_active = False
                self.continuous_alarm_sec = 0.0
            elif checked_dist_m > self.warning_dist_m:
                self.state = "MONITORING"
                self.alarm_active = False
                self.led_warning_active = False
                self.continuous_alarm_sec = 0.0
            else:
                # Inside Warning or Critical Zone
                if checked_dist_m <= self.critical_dist_m:
                    self.state = "CRITICAL_ALERT"
                    notification_outcome = self.notifier.send_critical_alert(
                        animal=det_res.mapped_class,
                        distance_m=checked_dist_m,
                        sensor_id=self.sensor_id,
                    )
                else:
                    self.state = "WILDLIFE_WARNING"

                # Animal welfare continuous sound limit check
                self.continuous_alarm_sec += dt_sec
                if self.continuous_alarm_sec <= self.max_continuous_alarm_sec:
                    self.alarm_active = True
                    self.led_warning_active = True
                else:
                    self.state = f"{self.state}_SAFETY_COOLDOWN"
                    self.alarm_active = False
                    self.led_warning_active = True
        else:
            self.state = "NORMAL_MONITORING"
            self.alarm_active = False
            self.led_warning_active = False
            self.continuous_alarm_sec = 0.0

        return {
            "state": self.state,
            "alarm_active": self.alarm_active,
            "led_warning_active": self.led_warning_active,
            "sensor_id": self.sensor_id,
            "sensor_status": self.sensor_status,
            "distance_m": checked_dist_m if valid_dist else None,
            "detection": asdict(det_res),
            "notification": notification_outcome,
        }


# ==============================================================================
# 6. TWO-WAY ESP32 SERIAL PROTOCOL MANAGER (WG3 PROTOCOL)
# ==============================================================================
class Esp32SerialManager:
    """
    Implements genuine two-way serial communication with physical ESP32 hardware
    over USB UART (115200 8N1) using the documented WG3 JSON framing protocol.
    """

    def __init__(self, port: str = "COM3", baud: int = 115200) -> None:
        self.port = port
        self.baud = baud
        self.ser: Optional[Any] = None
        self.connected_verified: bool = False
        self.last_telemetry: Dict[str, Any] = {}
        self.rx_log: List[str] = []
        self.tx_log: List[str] = []
        self.invalid_packet_count: int = 0
        self._stop_event = threading.Event()
        self._reader_thread: Optional[threading.Thread] = None

    @staticmethod
    def list_available_ports() -> List[Dict[str, str]]:
        if not HAS_PYSERIAL:
            return []
        ports = []
        for p in serial.tools.list_ports.comports():
            ports.append({
                "device": p.device,
                "description": p.description,
                "hwid": p.hwid,
            })
        return ports

    def connect(self) -> Tuple[bool, str]:
        if not HAS_PYSERIAL:
            self.connected_verified = False
            return False, "PySerial is not installed. Run: pip install pyserial"
        try:
            self.ser = serial.Serial(self.port, self.baud, timeout=1.0)
            time.sleep(0.3)
            # Send handshake packet to verify genuine WildGuard ESP32 firmware
            self.send_command({"proto": "WG3", "cmd": "handshake", "host": "WildGuardAI_Python_3.0"})
            self._stop_event.clear()
            self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
            self._reader_thread.start()
            return True, f"Serial port {self.port} opened at {self.baud} bps; awaiting WG3 telemetry handshake."
        except Exception as exc:
            self.connected_verified = False
            return False, f"We could not connect to your ESP32 on {self.port}. Check the USB cable and port name ({exc})."

    def disconnect(self) -> None:
        self._stop_event.set()
        self.connected_verified = False
        if self.ser and getattr(self.ser, "is_open", False):
            try:
                self.ser.close()
            except Exception:
                pass
        self.ser = None

    def send_command(self, payload: Dict[str, Any]) -> bool:
        if not self.ser or not getattr(self.ser, "is_open", False):
            return False
        try:
            payload.setdefault("proto", "WG3")
            line = json.dumps(payload, separators=(",", ":")) + "\n"
            self.ser.write(line.encode("utf-8"))
            self.tx_log.append(line.strip())
            if len(self.tx_log) > 100:
                self.tx_log.pop(0)
            return True
        except Exception as exc:
            logger.warning("Serial write failed: %s", exc)
            self.connected_verified = False
            return False

    def parse_incoming_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        """Safely parses incoming JSON lines and detects corrupt/incomplete frames."""
        line = raw_line.strip()
        if not line:
            return None
        if not (line.startswith("{") and line.endswith("}")):
            self.invalid_packet_count += 1
            return None
        try:
            data = json.loads(line)
            if not isinstance(data, dict) or data.get("proto") != "WG3":
                self.invalid_packet_count += 1
                return None
            self.connected_verified = True
            self.last_telemetry = data
            return data
        except json.JSONDecodeError:
            self.invalid_packet_count += 1
            return None

    def _read_loop(self) -> None:
        while not self._stop_event.is_set() and self.ser and getattr(self.ser, "is_open", False):
            try:
                raw_bytes = self.ser.readline()
                if not raw_bytes:
                    continue
                line = raw_bytes.decode("utf-8", errors="replace").strip()
                self.rx_log.append(line)
                if len(self.rx_log) > 100:
                    self.rx_log.pop(0)
                self.parse_incoming_line(line)
            except Exception as exc:
                logger.warning("ESP32 serial disconnected during read: %s", exc)
                self.connected_verified = False
                break


# ==============================================================================
# 7. AUTOMATED 10-SCENARIO & ENGINEERING VERIFICATION TEST SUITE
# ==============================================================================
def run_all_10_verification_scenarios() -> Dict[str, Any]:
    """
    Executes all 10 required wildlife & system logic scenarios against the actual
    WildGuardStateMachine, WildlifeClassifierFilter, and NotificationDispatcher.
    Records exact inputs, state transitions, and compares actual vs expected outputs.
    """
    db = WildGuardDatabase(":memory:")
    results: List[Dict[str, Any]] = []

    def simulate_scenario(
        test_id: int,
        name: str,
        species_frames: List[Tuple[List[Dict[str, Any]], float]],
        network_online: bool = True,
        expected_check=None,
    ) -> Dict[str, Any]:
        notifier = NotificationDispatcher(db, webhook_url="", cooldown_sec=10.0)
        notifier.network_simulated_online = network_online
        sm = WildGuardStateMachine(
            sensor_id="TF02_PRO_LIDAR",
            warning_dist_m=15.0,
            critical_dist_m=5.0,
            conf_threshold=0.70,
            confirm_frames=4,
            db=db,
            notifier=notifier,
        )
        transitions: List[str] = []
        alarm_ever_on = False
        led_ever_on = False
        critical_ever_triggered = False
        final_step: Dict[str, Any] = {}

        for dets, dist_m in species_frames:
            out = sm.evaluate_step(dets, dist_m, dt_sec=0.25)
            if not transitions or transitions[-1] != out["state"]:
                transitions.append(out["state"])
            if out["alarm_active"]:
                alarm_ever_on = True
            if out["led_warning_active"]:
                led_ever_on = True
            if out["state"] == "CRITICAL_ALERT":
                critical_ever_triggered = True
            final_step = out

        pending_cnt = len(db.get_pending_notifications())
        passed, expected_str, actual_str, fail_reason = expected_check(
            transitions, alarm_ever_on, led_ever_on, critical_ever_triggered, final_step, pending_cnt
        )
        return {
            "test_id": test_id,
            "name": name,
            "category": "SIMULATION_AND_STATE_MACHINE",
            "inputs": {
                "steps_executed": len(species_frames),
                "network_online": network_online,
                "sensor": "TF02_PRO_LIDAR (0.1m-40m)",
                "warning_m": 15.0,
                "critical_m": 5.0,
            },
            "state_transitions": transitions,
            "expected": expected_str,
            "actual": actual_str,
            "status": "PASS" if passed else "FAIL",
            "passed": passed,
            "failure_reason": fail_reason,
        }

    # Helper to build approaching then retreating sequence
    def make_retreat_steps(label: str, conf: float) -> List[Tuple[List[Dict[str, Any]], float]]:
        d = [{"label": label, "conf": conf, "bbox": [100, 80, 280, 260]}]
        steps = [
            (d, 22.0), (d, 20.5), (d, 19.0), (d, 17.5),  # 4 frames in Zone 1 -> Confirmed!
            (d, 14.2), (d, 12.8),                        # Enters Zone 2 (<=15m) -> WILDLIFE_WARNING & Alarm ON
            (d, 16.5), (d, 21.0),                        # Retreats outside Zone 2 (>15m) -> MONITORING & Alarm OFF
            ([], 28.0), ([], 28.0),                      # Exits -> NORMAL_MONITORING
        ]
        return steps

    # TEST 1: Elephant detected and retreats
    results.append(simulate_scenario(
        1,
        "Elephant detected and retreats",
        make_retreat_steps("elephant", 0.94),
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and al and led and not crit and fin["alarm_active"] is False),
            "Confirm elephant (4 frames), activate alarm <=15m, reset alarm to OFF after retreat >15m, 0 critical alerts.",
            f"Transitions: {' -> '.join(tr)} | Alarm Activated: {al} | Final Alarm: {fin['alarm_active']} | Critical: {crit}",
            None if ("WILDLIFE_WARNING" in tr and al and not crit and not fin["alarm_active"]) else "State machine transition mismatch",
        ),
    ))

    # TEST 2: Wild boar detected and retreats
    results.append(simulate_scenario(
        2,
        "Wild boar detected and retreats",
        make_retreat_steps("wild_boar", 0.91),
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and al and led and not crit and fin["alarm_active"] is False),
            "Confirm wild_boar (4 frames), activate alarm <=15m, reset alarm to OFF after retreat >15m.",
            f"Transitions: {' -> '.join(tr)} | Alarm Activated: {al} | Final Alarm: {fin['alarm_active']}",
            None,
        ),
    ))

    # TEST 3: Deer detected and retreats
    results.append(simulate_scenario(
        3,
        "Deer detected and retreats",
        make_retreat_steps("deer", 0.92),
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and al and led and not crit and fin["alarm_active"] is False),
            "Confirm deer (4 frames), activate alarm <=15m, reset alarm to OFF after retreat >15m.",
            f"Transitions: {' -> '.join(tr)} | Alarm Activated: {al} | Final Alarm: {fin['alarm_active']}",
            None,
        ),
    ))

    # TEST 4: Monkey detected and retreats
    results.append(simulate_scenario(
        4,
        "Monkey detected and retreats",
        make_retreat_steps("monkey", 0.89),
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and al and led and not crit and fin["alarm_active"] is False),
            "Confirm monkey (4 frames), activate alarm <=15m, reset alarm to OFF after retreat >15m.",
            f"Transitions: {' -> '.join(tr)} | Alarm Activated: {al} | Final Alarm: {fin['alarm_active']}",
            None,
        ),
    ))

    # TEST 5: Human detected without wildlife alarm
    human_d = [{"label": "person", "conf": 0.96, "bbox": [120, 60, 240, 300]}]
    human_steps = [(human_d, 20.0), (human_d, 18.0), (human_d, 16.0), (human_d, 12.0), (human_d, 4.0)]
    results.append(simulate_scenario(
        5,
        "Human detected without wildlife alarm",
        human_steps,
        True,
        lambda tr, al, led, crit, fin, q: (
            ("HUMAN_DETECTED" in tr and not al and not led and not crit),
            "Classify human, enter HUMAN_DETECTED state, keep alarm=OFF and LED=OFF even at 4.0m.",
            f"Transitions: {' -> '.join(tr)} | Alarm Ever ON: {al} | LED Ever ON: {led}",
            None if ("HUMAN_DETECTED" in tr and not al and not led) else "Human triggered alarm!",
        ),
    ))

    # TEST 6: Elephant ignores alarm and enters critical zone
    ele_d = [{"label": "elephant", "conf": 0.95, "bbox": [80, 50, 340, 290]}]
    ele_crit_steps = [
        (ele_d, 20.0), (ele_d, 18.0), (ele_d, 16.5), (ele_d, 14.5),
        (ele_d, 10.0), (ele_d, 4.5), (ele_d, 3.8),
    ]
    results.append(simulate_scenario(
        6,
        "Elephant ignores alarm and enters critical zone",
        ele_crit_steps,
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and "CRITICAL_ALERT" in tr and al and crit),
            "Escalate from WILDLIFE_WARNING (<=15m) to CRITICAL_ALERT (<=5m) and dispatch farmer notification.",
            f"Transitions: {' -> '.join(tr)} | Critical Triggered: {crit} | Alarm: {al}",
            None,
        ),
    ))

    # TEST 7: Animal exits warning zone before critical zone
    deer_d = [{"label": "deer", "conf": 0.91, "bbox": [110, 90, 260, 250]}]
    deer_warn_exit = [
        (deer_d, 19.0), (deer_d, 17.5), (deer_d, 16.0), (deer_d, 13.5),
        (deer_d, 11.2), (deer_d, 16.8), (deer_d, 20.0),
    ]
    results.append(simulate_scenario(
        7,
        "Animal exits warning zone before critical zone",
        deer_warn_exit,
        True,
        lambda tr, al, led, crit, fin, q: (
            ("WILDLIFE_WARNING" in tr and not crit and fin["state"] == "MONITORING" and not fin["alarm_active"]),
            "Activate alarm in Zone 2 (11.2m), stop alarm when animal exits >15m, send 0 critical alerts.",
            f"Transitions: {' -> '.join(tr)} | Critical Triggered: {crit} | Final State: {fin['state']}",
            None,
        ),
    ))

    # TEST 8: Temporary false detection rejected (2 frames < 4 required frames, plus dog non-target check)
    boar_d = [{"label": "wild_boar", "conf": 0.88, "bbox": [100, 100, 220, 220]}]
    dog_d = [{"label": "dog", "conf": 0.95, "bbox": [100, 100, 220, 220]}]
    glitch_steps = [
        (boar_d, 12.0), (boar_d, 12.0),  # Only 2 frames (<4 required)
        ([], 12.0), ([], 12.0),          # Glitch clears
        (dog_d, 8.0), (dog_d, 8.0), (dog_d, 8.0), (dog_d, 8.0),  # Dog must be rejected as UNSUPPORTED_SPECIES!
    ]
    results.append(simulate_scenario(
        8,
        "Temporary false detection & unsupported species (dog) rejected",
        glitch_steps,
        True,
        lambda tr, al, led, crit, fin, q: (
            (not al and not led and not crit and "UNSUPPORTED_SPECIES" in tr),
            "Reject 2-frame glitch (<4 frames) and reject 'dog' as UNSUPPORTED_SPECIES; Alarm stays OFF.",
            f"Transitions: {' -> '.join(tr)} | Alarm Ever ON: {al} | Final State: {fin['state']}",
            None,
        ),
    ))

    # TEST 9: Multiple animals detected simultaneously
    multi_d1 = [
        {"label": "deer", "conf": 0.86, "bbox": [40, 80, 160, 220]},
        {"label": "elephant", "conf": 0.95, "bbox": [180, 50, 380, 290]},
    ]
    multi_steps = [
        (multi_d1, 18.0), (multi_d1, 16.0), (multi_d1, 14.0), (multi_d1, 11.0), (multi_d1, 4.6),
    ]
    results.append(simulate_scenario(
        9,
        "Multiple animals detected simultaneously",
        multi_steps,
        True,
        lambda tr, al, led, crit, fin, q: (
            (al and crit and fin["detection"]["mapped_class"] == "elephant"),
            "Prioritize highest-confidence/closest threat (elephant 95%), trigger warning then critical alert at 4.6m.",
            f"Tracked Primary: {fin['detection']['mapped_class']} ({fin['detection']['confidence']*100:.0f}%) | Transitions: {' -> '.join(tr)}",
            None,
        ),
    ))

    # TEST 10: Network disconnects and notification is queued
    offline_steps = [
        (ele_d, 19.0), (ele_d, 17.0), (ele_d, 15.5), (ele_d, 13.0), (ele_d, 4.2),
    ]
    results.append(simulate_scenario(
        10,
        "Network disconnects and notification is queued as PENDING",
        offline_steps,
        False,
        lambda tr, al, led, crit, fin, q: (
            (al and crit and fin["notification"] is not None and fin["notification"]["status"] == "PENDING" and q >= 1),
            "Activate local alarm at <=15m while offline; at <=5m store alert in SQLite queue with status=PENDING.",
            f"Local Alarm: {al} | Notification Status: {fin['notification']['status'] if fin['notification'] else 'NONE'} | Pending Queue Count: {q}",
            None,
        ),
    ))

    # Bonus Engineering Verification: HC-SR04 4.0m Range Limit Check
    valid_15m, status_15m, _ = validate_sensor_measurement("HC_SR04_LAB", 15.0)
    valid_2m, status_2m, _ = validate_sensor_measurement("HC_SR04_LAB", 2.1)

    return {
        "executed_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_scenarios": len(results),
        "passed_count": sum(1 for r in results if r["passed"]),
        "failed_count": sum(1 for r in results if not r["passed"]),
        "hcsr04_15m_rejected": (not valid_15m and status_15m == "OUT_OF_RANGE_MAX_4.0M"),
        "hcsr04_2m_accepted": (valid_2m and status_2m == "VALID_MEASUREMENT"),
        "scenarios": results,
    }


# ==============================================================================
# 8. REAL USB WEBCAM + YOLO INFERENCE LOOP & LOCAL HTTP BRIDGE SERVER
# ==============================================================================
class WildGuardBridgeRuntime:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.db = WildGuardDatabase(args.db)
        self.notifier = NotificationDispatcher(
            self.db,
            webhook_url=args.webhook,
            farmer_phone=args.phone,
        )
        self.sm = WildGuardStateMachine(
            sensor_id=args.sensor,
            warning_dist_m=args.warn_dist,
            critical_dist_m=args.crit_dist,
            conf_threshold=args.conf,
            confirm_frames=args.confirm_frames,
            db=self.db,
            notifier=self.notifier,
        )
        self.serial_mgr = Esp32SerialManager(port=args.port, baud=args.baud)
        self.model: Optional[Any] = None
        self.model_audit: Dict[str, Any] = {}
        self.camera_connected: bool = False
        self.latest_status: Dict[str, Any] = {
            "mode": "INITIALIZING",
            "camera_connected": False,
            "esp32_connected": False,
            "model_loaded": False,
        }

    def load_ai_model(self, model_path: str) -> Tuple[bool, str]:
        if not HAS_ULTRALYTICS:
            return (
                False,
                "Ultralytics YOLO library is not installed in this Python environment. "
                "Install with: pip install ultralytics opencv-python pyserial",
            )
        try:
            self.model = YOLO(model_path)
            names = getattr(self.model, "names", {})
            self.model_audit = self.sm.classifier.inspect_model_classes(names)
            logger.info("Loaded YOLO model '%s': %s", model_path, self.model_audit["limitation_notice"])
            return True, self.model_audit["limitation_notice"]
        except Exception as exc:
            self.model = None
            return (
                False,
                f"The AI detection model '{model_path}' could not start ({exc}). "
                "Please check that a compatible .pt or .onnx model file is installed.",
            )

    def run_camera_loop(self) -> None:
        if not HAS_OPENCV:
            logger.error("OpenCV (cv2) is not installed. Run: pip install opencv-python")
            return

        cap = cv2.VideoCapture(self.args.camera)
        if not cap.isOpened():
            logger.error(
                "We could not open USB camera index %s. Check that your webcam is plugged in and not used by another app.",
                self.args.camera,
            )
            self.camera_connected = False
            return

        self.camera_connected = True
        logger.info("USB Webcam (index %s) opened. Starting real-time inference loop...", self.args.camera)

        while True:
            ok, frame = cap.read()
            if not ok or frame is None:
                logger.warning("Camera frame read failed; retrying...")
                time.sleep(0.1)
                continue

            raw_dets: List[Dict[str, Any]] = []
            if self.model is not None:
                results = self.model.predict(frame, conf=self.args.conf, verbose=False)
                for r in results:
                    names = r.names
                    for box in r.boxes:
                        cls_id = int(box.cls[0].item())
                        conf_val = float(box.conf[0].item())
                        xyxy = [int(v) for v in box.xyxy[0].tolist()]
                        raw_dets.append({
                            "label": names.get(cls_id, str(cls_id)),
                            "conf": conf_val,
                            "bbox": xyxy,
                        })

            # Read real distance from ESP32 if connected, else mark sensor disconnected
            if self.serial_mgr.connected_verified and "dist_cm" in self.serial_mgr.last_telemetry:
                dist_m = float(self.serial_mgr.last_telemetry["dist_cm"]) / 100.0
            else:
                dist_m = -1.0

            step_out = self.sm.evaluate_step(raw_dets, dist_m, dt_sec=0.1)

            # Transmit AI detection state to ESP32 over USB Serial
            if self.serial_mgr.connected_verified:
                det_info = step_out["detection"]
                self.serial_mgr.send_command({
                    "proto": "WG3",
                    "cmd": "ai_frame",
                    "class": det_info["mapped_class"],
                    "conf": det_info["confidence"],
                    "frames": det_info["consecutive_frames"],
                    "confirmed": det_info["confirmed"],
                    "warn_m": self.sm.warning_dist_m,
                    "crit_m": self.sm.critical_dist_m,
                })

            # Annotate OpenCV preview window
            det = step_out["detection"]
            if det["bbox"] != [0, 0, 0, 0]:
                x1, y1, x2, y2 = det["bbox"]
                color = (0, 255, 0) if det["confirmed"] else (0, 200, 255)
                if det["mapped_class"] == "unsupported":
                    color = (128, 128, 128)
                elif step_out["state"] == "CRITICAL_ALERT":
                    color = (0, 0, 255)
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                caption = (
                    f"{det['mapped_class'].upper()} ({det['raw_label']}) "
                    f"{det['confidence']*100:.1f}% [{det['consecutive_frames']}/{det['required_frames']}]"
                )
                cv2.putText(frame, caption, (x1, max(20, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

            if not self.args.headless:
                cv2.imshow("WildGuard AI 3.0 - Live Camera Feed", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

        cap.release()
        if not self.args.headless:
            cv2.destroyAllWindows()


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="WildGuard AI 3.0 — Real Camera, YOLO, SQLite & ESP32 Bridge")
    p.add_argument("--port", default="COM3", help="ESP32 Serial Port (e.g. COM3 on Windows, /dev/ttyUSB0 on Linux)")
    p.add_argument("--baud", type=int, default=115200, help="Serial baud rate (default: 115200)")
    p.add_argument("--camera", type=int, default=0, help="USB Webcam device index (default: 0)")
    p.add_argument("--model", default="yolov8n.pt", help="Path to YOLO .pt or .onnx wildlife model")
    p.add_argument("--class-map", default="", help="Optional JSON file mapping custom model labels to WildGuard classes")
    p.add_argument("--sensor", default="TF02_PRO_LIDAR", choices=list(SENSOR_CATALOG.keys()), help="Installed physical distance sensor")
    p.add_argument("--warn-dist", type=float, default=15.0, help="Warning zone threshold in metres")
    p.add_argument("--crit-dist", type=float, default=5.0, help="Critical zone threshold in metres")
    p.add_argument("--conf", type=float, default=0.70, help="Minimum AI confidence threshold (0.50 - 0.95)")
    p.add_argument("--confirm-frames", type=int, default=4, help="Consecutive frames required to confirm detection")
    p.add_argument("--db", default="wildguard_data.db", help="SQLite database file path")
    p.add_argument("--webhook", default="", help="Configured HTTP Webhook / SMS Gateway URL")
    p.add_argument("--phone", default="", help="Farmer destination phone number")
    p.add_argument("--headless", action="store_true", help="Run without OpenCV GUI window")
    p.add_argument("--run-self-tests", action="store_true", help="Execute the 10-scenario & engineering test suite and exit")
    return p


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()

    if args.run_self_tests:
        report = run_all_10_verification_scenarios()
        print(json.dumps(report, indent=2))
        sys.exit(0 if report["failed_count"] == 0 else 1)

    logger.info("==================================================================")
    logger.info("WILDGUARD AI 3.0 — PYTHON AI VISION & ESP32 HARDWARE BRIDGE")
    logger.info("==================================================================")
    logger.info("Installed Sensor Profile : %s", SENSOR_CATALOG[args.sensor]["name"])
    logger.info("Operating Range          : %.2fm – %.2fm", SENSOR_CATALOG[args.sensor]["min_range_m"], SENSOR_CATALOG[args.sensor]["max_range_m"])
    logger.info("Supported Target Species : %s + human (safe rule)", sorted(TARGET_WILDLIFE_CLASSES))
    logger.info("Forbidden Proxy Mappings : %s (strictly rejected as UNSUPPORTED_SPECIES)", sorted(FORBIDDEN_PROXY_CLASSES))

    runtime = WildGuardBridgeRuntime(args)
    if args.class_map:
        runtime.sm.classifier.load_custom_class_map(args.class_map)
    ok_serial, msg_serial = runtime.serial_mgr.connect()
    logger.info("ESP32 Serial Status      : %s", msg_serial)
    ok_model, msg_model = runtime.load_ai_model(args.model)
    logger.info("AI Model Status          : %s", msg_model)
    runtime.run_camera_loop()


if __name__ == "__main__":
    main()
