# WildGuard AI 3.0 — Verified ESP32 Circuit Connections, Multi-Sensor Architecture & Electrical Safety Guide

## 1. Multi-Sensor Pin Assignment Table (ESP32 DevKit V1 — 3.3V CMOS Logic)

| Component / Terminal | ESP32 / Breadboard Connection | Electrical Specification & Safety Rationale |
| :--- | :--- | :--- |
| **Benewake TF02-Pro LiDAR VCC** | `External 5V–12V DC` (Common GND) | Outdoor IP65 LiDAR (0.1m–40.0m range); UART TX/RX uses safe **3.3V LVTTL logic**. |
| **Benewake TF02-Pro LiDAR TX/RX** | `ESP32 GPIO 16 (RX2)` / `GPIO 17 (TX2)` | Direct 3.3V UART2 connection at 115200 bps. |
| **HC-SR04 / JSN-SR04T VCC** | `ESP32 VIN (5V)` / `+5V Rail` | Requires 5.0V DC operating voltage (~15 mA). HC-SR04 is strictly for indoor bench demos (0.02m–4.00m). |
| **HC-SR04 / JSN-SR04T TRIG** | `ESP32 GPIO 5` | 3.3V CMOS output from ESP32 exceeds ultrasonic minimum `V_IH` (2.0V). |
| **HC-SR04 / JSN-SR04T ECHO** | `GPIO 18` **via 1kΩ + 2kΩ Divider** | `ECHO` outputs **5.0V**. `1kΩ` series + `2kΩ` to `GND` steps 5.0V down to **3.33V** to protect the 3.3V-only ESP32 GPIO! |
| **Warning LED Anode (+)** | `ESP32 GPIO 19` **via 220Ω Resistor** | Limits LED forward current to `(3.3V - 2.0V) / 220Ω = 5.9 mA` (well below 12mA ESP32 GPIO limit). |
| **Warning LED Cathode (-)** | `Common GND` | Completes LED return path to ground. |
| **Active Buzzer Module (I/O)** | `ESP32 GPIO 23` | Drives onboard NPN transistor base on the 3-pin active buzzer module (`VCC -> 5V`, `GND -> GND`). Keeps GPIO pin current `<2 mA`. |
| **Optional Strobe Relay (IN)** | `ESP32 GPIO 22` | Drives opto-isolated 5V relay module input for external visual strobe. |
| **Common Ground** | `ESP32 GND` | Shared 0V reference ground across ESP32, sensor, 2kΩ divider leg, LED cathode, buzzer, and power supply. |

## 2. Voltage Divider Calculation for 5V Ultrasonic ECHO (`GPIO 18`)

```text
  HC-SR04 / JSN-SR04T ECHO (5.0V)
         │
      [ 1kΩ ]  (R1 = 1000 Ω, Brown-Black-Red-Gold)
         │
         ├───────────────► To ESP32 GPIO 18 (V_out = 5.0V × 2000 / (1000 + 2000) = 3.33V SAFE!)
         │
      [ 2kΩ ]  (R2 = 2000 Ω, Red-Black-Red-Gold)
         │
    Common GND (0V)
```
