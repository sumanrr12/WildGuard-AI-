// ============================================================================
// WILDGUARD AI 3.0 — MODULE 2: TWO-WAY WEB SERIAL API, USB WEBCAM & IOT ENGINE
// File: src/js/02_hardware_serial_and_camera.js
// ============================================================================

const WildGuardSerialManager = {
  port: null,
  reader: null,
  writer: null,
  keepReading: false,
  portOpen: false,
  handshakeVerified: false, // NEVER true until genuine WG3 frame received from ESP32!
  rxBuffer: '',
  rxPacketsCount: 0,
  txPacketsCount: 0,
  invalidFramesCount: 0,
  lastTelemetry: null,
  serialLogs: [],

  logSerial(dir, text) {
    const ts = new Date().toLocaleTimeString([], { hour12: false });
    this.serialLogs.unshift(`[${ts}] [${dir}] ${text}`);
    if (this.serialLogs.length > 80) this.serialLogs.pop();
    const logEl = document.getElementById('expertSerialLogBox');
    if (logEl) {
      logEl.textContent = this.serialLogs.join('\n');
    }
  },

  async connectEsp32(onVerifiedCallback, onStatusCallback) {
    if (!('serial' in navigator)) {
      const friendly = 'Your current browser does not support USB Web Serial. Please open WildGuard AI in Google Chrome or Microsoft Edge on your computer.';
      onStatusCallback(false, 'UNSUPPORTED_BROWSER', friendly);
      return false;
    }

    try {
      this.port = await navigator.serial.requestPort();
      await this.port.open({ baudRate: 115200 });
      this.portOpen = true;
      this.handshakeVerified = false;
      this.rxBuffer = '';

      onStatusCallback(
        false,
        'PORT_OPEN_AWAITING_HANDSHAKE',
        'USB port opened at 115200 bps. Verifying genuine ESP32 WildGuard WG3 handshake...'
      );

      // Start asynchronous read loop
      this.keepReading = true;
      this.readLoop(onVerifiedCallback, onStatusCallback);

      // Send WG3 handshake request
      await this.sendCommand({ proto: 'WG3', cmd: 'handshake', client: 'WildGuard_Web_3.0' });

      // Wait up to 2.5s for genuine ESP32 WG3 response before warning user
      setTimeout(() => {
        if (this.portOpen && !this.handshakeVerified) {
          onStatusCallback(
            false,
            'UNVERIFIED_DEVICE',
            'Serial port is open, but no WG3 telemetry packet was received yet. Make sure esp32_wildguard_firmware.ino is flashed to your ESP32. System will NOT claim REAL HARDWARE CONNECTED until verified.'
          );
        }
      }, 2500);

      return true;
    } catch (err) {
      this.portOpen = false;
      this.handshakeVerified = false;
      const friendly = 'We could not connect to your ESP32. Check the USB data cable, ensure no other program (like Arduino Serial Monitor) is using the port, and try again.';
      onStatusCallback(false, 'CONNECTION_FAILED', `${friendly} (${err.message || 'Cancelled'})`);
      return false;
    }
  },

  async sendCommand(payloadObj) {
    if (!this.port || !this.portOpen || !this.port.writable) return false;
    try {
      const obj = Object.assign({ proto: 'WG3' }, payloadObj);
      const line = JSON.stringify(obj) + '\n';
      const writer = this.port.writable.getWriter();
      await writer.write(new TextEncoder().encode(line));
      writer.releaseLock();
      this.txPacketsCount++;
      this.logSerial('TX -> ESP32', line.trim());
      return true;
    } catch (err) {
      this.logSerial('TX_ERR', err.message);
      return false;
    }
  },

  async readLoop(onVerifiedCallback, onStatusCallback) {
    while (this.port && this.port.readable && this.keepReading) {
      try {
        this.reader = this.port.readable.getReader();
        const decoder = new TextDecoder();
        while (true) {
          const { value, done } = await this.reader.read();
          if (done) break;
          if (value) {
            this.rxBuffer += decoder.decode(value, { stream: true });
            let newlineIdx;
            while ((newlineIdx = this.rxBuffer.indexOf('\n')) >= 0) {
              const rawLine = this.rxBuffer.slice(0, newlineIdx).trim();
              this.rxBuffer = this.rxBuffer.slice(newlineIdx + 1);
              if (rawLine.length > 0) {
                this.handleIncomingLine(rawLine, onVerifiedCallback, onStatusCallback);
              }
            }
          }
        }
      } catch (err) {
        this.logSerial('RX_ERR', `Serial read interrupted: ${err.message}`);
        break;
      } finally {
        if (this.reader) {
          try { this.reader.releaseLock(); } catch (e) {}
          this.reader = null;
        }
      }
    }

    if (this.portOpen) {
      this.portOpen = false;
      this.handshakeVerified = false;
      onStatusCallback(
        false,
        'DISCONNECTED',
        'ESP32 USB connection was unplugged or closed. Reverted safely to Simulation Mode.'
      );
    }
  },

  handleIncomingLine(line, onVerifiedCallback, onStatusCallback) {
    this.logSerial('RX <- ESP32', line);
    if (!line.startsWith('{') || !line.endsWith('}')) {
      this.invalidFramesCount++;
      this.updateSerialMetricsUI();
      return;
    }
    try {
      const pkt = JSON.parse(line);
      if (pkt.proto !== 'WG3') {
        this.invalidFramesCount++;
        this.updateSerialMetricsUI();
        return;
      }
      this.rxPacketsCount++;
      const wasVerified = this.handshakeVerified;
      this.handshakeVerified = true;
      this.lastTelemetry = pkt;
      this.updateSerialMetricsUI();

      if (!wasVerified) {
        onStatusCallback(
          true,
          'REAL_HARDWARE_VERIFIED',
          `Verified two-way WG3 communication with ESP32 (Sensor: ${pkt.sensor || 'TF02_PRO_LIDAR'}). Live hardware telemetry active.`
        );
      }
      if (onVerifiedCallback) {
        onVerifiedCallback(pkt);
      }
    } catch (e) {
      this.invalidFramesCount++;
      this.updateSerialMetricsUI();
    }
  },

  updateSerialMetricsUI() {
    const rxEl = document.getElementById('serialRxCount');
    const txEl = document.getElementById('serialTxCount');
    const errEl = document.getElementById('serialInvalidCount');
    if (rxEl) rxEl.textContent = String(this.rxPacketsCount);
    if (txEl) txEl.textContent = String(this.txPacketsCount);
    if (errEl) errEl.textContent = String(this.invalidFramesCount);
  },

  async disconnectEsp32(onStatusCallback) {
    this.keepReading = false;
    if (this.reader) {
      try { await this.reader.cancel(); } catch (e) {}
    }
    if (this.port) {
      try { await this.port.close(); } catch (e) {}
    }
    this.port = null;
    this.portOpen = false;
    this.handshakeVerified = false;
    if (onStatusCallback) {
      onStatusCallback(false, 'DISCONNECTED', 'Disconnected from ESP32 USB port. Running in Simulation Mode.');
    }
  }
};

// 2. REAL USB WEBCAM & AI BRIDGE CONNECTOR
const WildGuardCameraManager = {
  stream: null,
  videoEl: null,
  cameraActive: false,
  bridgeWsConnected: false,
  customClassMap: Object.assign({}, STRICT_CLASS_MAP_3),
  modelStatusText: 'No local YOLO bridge connected (Run python wildguard_ai_serial_bridge.py for live YOLOv8 inference)',

  async startUsbWebcam(videoElementId, statusCallback) {
    const video = document.getElementById(videoElementId);
    if (!video) return false;
    this.videoEl = video;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      statusCallback(false, 'We could not access your USB camera because browser camera permissions are unavailable.');
      return false;
    }

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 360 } },
        audio: false
      });
      video.srcObject = this.stream;
      await video.play();
      this.cameraActive = true;
      statusCallback(
        true,
        'Real USB Webcam active! Live video feed is displayed. Note: No fake AI detections are generated on raw webcam video—connect the Python YOLO bridge for real bounding boxes.'
      );
      return true;
    } catch (err) {
      this.cameraActive = false;
      statusCallback(
        false,
        `We could not open your USB camera. Please allow camera permission in your browser and check the USB connection (${err.message}).`
      );
      return false;
    }
  },

  stopUsbWebcam(statusCallback) {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop());
      this.stream = null;
    }
    if (this.videoEl) {
      this.videoEl.srcObject = null;
    }
    this.cameraActive = false;
    if (statusCallback) {
      statusCallback(false, 'USB Webcam stopped. Using 3D Tower Camera simulation.');
    }
  }
};
