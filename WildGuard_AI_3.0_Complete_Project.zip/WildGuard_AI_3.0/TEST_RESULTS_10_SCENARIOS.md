# WildGuard AI 3.0 — Automated Verification Report (10 Scenarios, AI Filter & Hardware Checks)

## 1. Software Simulation & State-Machine Test Suite (Executed via `wildguard_ai_serial_bridge.py --run-self-tests` & Browser Runner)

| Test ID | Scenario Name | Recorded Inputs | Recorded State Transitions | Actual Verified Output | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TEST 1** | Elephant detected and retreats | `species=elephant`, `conf=0.94`, `frames=4`, `sensor=TF02_PRO_LIDAR`, `warn=15m`, `crit=5m` | `NORMAL_MONITORING -> MONITORING -> WILDLIFE_WARNING -> MONITORING -> NORMAL_MONITORING` | Confirmed in 4 frames; Alarm & LED `ON` at `<=15m`; reset to `OFF` after retreat `>15m`; `0` critical alerts. | **PASS** |
| **TEST 2** | Wild boar detected and retreats | `species=wild_boar`, `conf=0.91`, `frames=4`, `sensor=TF02_PRO_LIDAR`, `warn=15m`, `crit=5m` | `NORMAL_MONITORING -> MONITORING -> WILDLIFE_WARNING -> MONITORING -> NORMAL_MONITORING` | Confirmed in 4 frames; Alarm & LED `ON` at `<=15m`; reset to `OFF` after retreat `>15m`. | **PASS** |
| **TEST 3** | Deer detected and retreats | `species=deer`, `conf=0.92`, `frames=4`, `sensor=TF02_PRO_LIDAR`, `warn=15m`, `crit=5m` | `NORMAL_MONITORING -> MONITORING -> WILDLIFE_WARNING -> MONITORING -> NORMAL_MONITORING` | Confirmed in 4 frames; Alarm & LED `ON` at `<=15m`; reset to `OFF` after retreat `>15m`. | **PASS** |
| **TEST 4** | Monkey detected and retreats | `species=monkey`, `conf=0.89`, `frames=4`, `sensor=TF02_PRO_LIDAR`, `warn=15m`, `crit=5m` | `NORMAL_MONITORING -> MONITORING -> WILDLIFE_WARNING -> MONITORING -> NORMAL_MONITORING` | Confirmed in 4 frames; Alarm & LED `ON` at `<=15m`; hesitated then retreated `>15m`; Alarm `OFF`. | **PASS** |
| **TEST 5** | Human detected without wildlife alarm | `species=person->human`, `conf=0.96`, `frames=4`, `dist=20m->4.0m` | `NORMAL_MONITORING -> HUMAN_DETECTED` | Entered `HUMAN_DETECTED` state; `Alarm=OFF`, `LED=OFF` even at `4.0m`; silent log saved. | **PASS** |
| **TEST 6** | Elephant ignores alarm and enters critical zone | `species=elephant`, `conf=0.95`, `frames=4`, `dist=20m->3.8m` | `NORMAL_MONITORING -> WILDLIFE_WARNING -> CRITICAL_ALERT` | Escalated from `WILDLIFE_WARNING` (`<=15m`) to `CRITICAL_ALERT` (`<=5m`); triggered notification dispatcher. | **PASS** |
| **TEST 7** | Animal exits warning zone before critical zone | `species=deer`, `conf=0.91`, `frames=4`, `dist=19m->11.2m->20m` | `NORMAL_MONITORING -> WILDLIFE_WARNING -> MONITORING` | Alarm `ON` at `11.2m`; stopped when animal exited `>15m`; `0` critical alerts sent. | **PASS** |
| **TEST 8** | Temporary false detection & non-target (`dog`) rejected | `wild_boar` (`2/4 frames`) + `dog` (`4 frames, conf=0.95`) | `NORMAL_MONITORING -> UNSUPPORTED_SPECIES` | 2-frame glitch rejected; `dog` rejected as `UNSUPPORTED_SPECIES` (no false proxy to monkey); `Alarm=OFF`. | **PASS** |
| **TEST 9** | Multiple animals detected simultaneously | `deer (86%) + elephant (95%)`, `dist=18m->4.6m` | `NORMAL_MONITORING -> WILDLIFE_WARNING -> CRITICAL_ALERT` | Prioritized highest-threat target (`elephant`), triggered warning then critical alert at `4.6m`. | **PASS** |
| **TEST 10** | Network disconnects and notification is queued | `network=OFFLINE`, `species=elephant`, `dist=19m->4.2m` | `NORMAL_MONITORING -> WILDLIFE_WARNING -> CRITICAL_ALERT` | Local ESP32 Alarm `ON` at `<=15m`; at `4.2m` alert saved in persistent SQLite/LocalStorage queue as `PENDING`. | **PASS** |

## 2. Engineering Unit & Hardware Verification Status

| Verification Module | Test Method | Result | Notes |
| :--- | :--- | :--- | :--- |
| **Anti-Proxy Class Filter (`dog`, `sheep`, `bear`)** | `tests/test_wildguard_suite.py` (`test_02`) | **PASS** | Verified `dog`, `sheep`, `bear`, `cow`, `cat`, `bird` map to `unsupported` and never trigger deterrents. |
| **Sensor Range Enforcement (`HC-SR04` 4.0m Cap)** | `tests/test_wildguard_suite.py` (`test_03`) | **PASS** | `HC_SR04_LAB` rejects `15.0m` with `OUT_OF_RANGE_MAX_4.0M`; `TF02_PRO_LIDAR` accepts `15.0m`. |
| **SQLite Persistence & Offline Queue** | `tests/test_wildguard_suite.py` (`test_04`) | **PASS** | Verified SQLite table creation, offline `PENDING` alert queueing, and CSV export. |
| **WG3 Serial Framing & Corrupt Packet Filter** | `tests/test_wildguard_suite.py` (`test_05`) | **PASS** | Corrupt/non-WG3 serial lines increment `invalid_packet_count` and do not set `connected_verified`. |
| **Animal Welfare 30s Continuous Sound Cutoff** | `tests/test_wildguard_suite.py` (`test_06`) | **PASS** | Continuous alarm automatically enters `SAFETY_COOLDOWN` after exceeding maximum duration. |
| **Physical ESP32 & USB Camera Hardware Tests** | Live USB Hardware Bench | **REQUIRES PHYSICAL HARDWARE** | Requires user to connect physical ESP32 via USB Serial and USB Webcam on local machine. |
