#!/usr/bin/env python3
"""
WildGuard AI 3.0 — Comprehensive Unit & Integration Test Suite
Tests:
  1. All 10 Wildlife Protection Scenarios (State Machine + Consecutive Frame Confirmation)
  2. Strict Anti-Proxy Wildlife Classification (dog != monkey, sheep != deer, bear != boar)
  3. Sensor Operating Range Enforcement (HC-SR04 strictly rejects 15m; TF02-Pro LiDAR accepts 15m)
  4. Persistent SQLite Storage (detections, offline notification queue, CSV export)
  5. WG3 Two-Way Serial Framing & Corrupt Packet Rejection
  6. Continuous Deterrent Animal Welfare Cutoff (30s maximum continuous alarm)
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "python_ai_bridge")))

from wildguard_ai_serial_bridge import (
    WildlifeClassifierFilter,
    WildGuardDatabase,
    NotificationDispatcher,
    WildGuardStateMachine,
    Esp32SerialManager,
    validate_sensor_measurement,
    run_all_10_verification_scenarios,
)


class WildGuardEngineeringTestSuite(unittest.TestCase):
    def test_01_all_10_scenarios_pass_state_machine(self):
        report = run_all_10_verification_scenarios()
        self.assertEqual(report["total_scenarios"], 10)
        self.assertEqual(report["failed_count"], 0)
        self.assertEqual(report["passed_count"], 10)
        self.assertTrue(report["hcsr04_15m_rejected"])
        self.assertTrue(report["hcsr04_2m_accepted"])

    def test_02_forbidden_proxy_classes_strictly_rejected(self):
        clf = WildlifeClassifierFilter(conf_threshold=0.70, confirm_frames=2)
        for non_target in ["dog", "sheep", "bear", "cow", "cat", "bird"]:
            res = clf.process_frame_detections([{"label": non_target, "conf": 0.96, "bbox": [10, 10, 200, 200]}])
            self.assertEqual(res.mapped_class, "unsupported")
            self.assertEqual(res.category, "UNSUPPORTED_SPECIES")
            self.assertFalse(res.confirmed)

    def test_03_sensor_range_validation_never_allows_hcsr04_15m(self):
        ok_15, status_15, _ = validate_sensor_measurement("HC_SR04_LAB", 15.0)
        self.assertFalse(ok_15)
        self.assertEqual(status_15, "OUT_OF_RANGE_MAX_4.0M")

        ok_3, status_3, val_3 = validate_sensor_measurement("HC_SR04_LAB", 3.2)
        self.assertTrue(ok_3)
        self.assertEqual(status_3, "VALID_MEASUREMENT")
        self.assertAlmostEqual(val_3, 3.2)

        ok_lidar_15, status_lidar_15, val_lidar_15 = validate_sensor_measurement("TF02_PRO_LIDAR", 15.0)
        self.assertTrue(ok_lidar_15)
        self.assertEqual(status_lidar_15, "VALID_MEASUREMENT")
        self.assertAlmostEqual(val_lidar_15, 15.0)

    def test_04_sqlite_persistence_and_offline_queue(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            db_file = os.path.join(tmpdir, "test_wg.db")
            db = WildGuardDatabase(db_file)
            notifier = NotificationDispatcher(db, webhook_url="", cooldown_sec=5.0)
            notifier.network_simulated_online = False

            out = notifier.send_critical_alert("elephant", 4.1, "TF02_PRO_LIDAR")
            self.assertEqual(out["status"], "PENDING")

            pending = db.get_pending_notifications()
            self.assertEqual(len(pending), 1)
            self.assertEqual(pending[0]["animal"], "elephant")
            self.assertEqual(pending[0]["status"], "PENDING")

            # Verify CSV export
            db.record_detection({
                "source_mode": "REAL_HARDWARE",
                "raw_label": "elephant",
                "mapped_class": "elephant",
                "confidence": 0.93,
                "consecutive_frames": 4,
                "confirmed": True,
                "sensor_id": "TF02_PRO_LIDAR",
                "distance_m": 12.4,
                "system_state": "WILDLIFE_WARNING",
                "alarm_active": True,
                "notes": "Unit test detection",
            })
            csv_path = os.path.join(tmpdir, "export.csv")
            db.export_detections_csv(csv_path)
            self.assertTrue(os.path.exists(csv_path))

    def test_05_serial_protocol_parser_rejects_corrupt_frames(self):
        mgr = Esp32SerialManager()
        self.assertIsNone(mgr.parse_incoming_line("corrupt_partial_line"))
        self.assertIsNone(mgr.parse_incoming_line("{\"unrelated\":123}"))
        self.assertEqual(mgr.invalid_packet_count, 2)
        self.assertFalse(mgr.connected_verified)

        valid_pkt = mgr.parse_incoming_line(
            '{"proto":"WG3","type":"telemetry","seq":1,"source":"REAL_HARDWARE","dist_cm":1240.0,"state":"WILDLIFE_WARNING"}'
        )
        self.assertIsNotNone(valid_pkt)
        self.assertTrue(mgr.connected_verified)
        self.assertEqual(valid_pkt["state"], "WILDLIFE_WARNING")

    def test_06_continuous_alarm_safety_cutoff(self):
        sm = WildGuardStateMachine(
            sensor_id="TF02_PRO_LIDAR",
            warning_dist_m=15.0,
            critical_dist_m=5.0,
            confirm_frames=2,
            max_continuous_alarm_sec=5.0,
        )
        dets = [{"label": "elephant", "conf": 0.95, "bbox": [50, 50, 250, 250]}]
        sm.evaluate_step(dets, 12.0, dt_sec=1.0)
        out2 = sm.evaluate_step(dets, 12.0, dt_sec=1.0)
        self.assertTrue(out2["alarm_active"])

        # Advance past 5.0s max continuous sound threshold
        out_cutoff = sm.evaluate_step(dets, 12.0, dt_sec=4.5)
        self.assertFalse(out_cutoff["alarm_active"])
        self.assertTrue(out_cutoff["led_warning_active"])
        self.assertIn("SAFETY_COOLDOWN", out_cutoff["state"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
