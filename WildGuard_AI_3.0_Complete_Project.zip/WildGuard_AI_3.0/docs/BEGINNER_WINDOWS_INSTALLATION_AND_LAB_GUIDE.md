# WILDGUARD AI — BEGINNER WINDOWS INSTALLATION & 3D VIRTUAL HARDWARE LAB GUIDE

## 1. Exact Windows Instructions to Extract and Run (Zero Coding Required)
1. **Download the ZIP File**: Save `WildGuard_AI_3.0_Complete_Project.zip` to your Windows **Downloads** folder or **Desktop**.
2. **Extract (Unpack) the ZIP File**:
   - Right-click on `WildGuard_AI_3.0_Complete_Project.zip`.
   - Click **Extract All...** in the menu.
   - Click **Extract** at the bottom of the window. A new unzipped folder will open automatically.
3. **Open the Application in Your Browser**:
   - Open the `WildGuard_AI_3.0` folder.
   - Double-click **`index.html`** (it will open directly inside **Google Chrome** or **Microsoft Edge**).
   - *Tip*: If double-clicking opens Notepad instead, right-click `index.html`, hover over **Open with**, and click **Google Chrome** or **Microsoft Edge**.

## 2. How to Use the Upgraded 3D Component Assembly & Virtual Hardware Lab (Environment B)
1. **Open the 3D Electronics Lab**:
   - In the top navigation bar, click **`🔧 3D Component Lab (Env B)`** (or **`⚡ Coupled Split View (Env A + B)`** to watch the 3D Farm and 3D Hardware Lab side by side).
2. **Explore All 24 Interactive 3D Components**:
   - Click any component in **1. 3D Component Library** on the left (or click directly on the 3D part on the workbench) to see its highlighted 3D pins, beginner explanation, common wiring mistakes, and datasheet specifications.
   - Use **`X - / X +`**, **`Y - / Y +`**, **`Z - / Z +`**, and **`Rotate -45° / +45°`** to move and orient components, or drag them directly on the workbench with your mouse.
3. **Connect Wires in 3D or Follow the Guided Beginner Tutorial**:
   - **Direct 3D Pin Clicking**: Click any glowing 3D pin sphere on a component to select it as **Source Pin A**, then click a second 3D pin sphere to snap a color-coded jumper wire between them.
   - **Automatic Assembly**: Click **`🔧 BUILD COMPLETE WILDGUARD CIRCUIT`** to automatically place all 24 components, wire the complete circuit, run electrical Design Rule Checking (DRC), and display the synchronized 2D schematic.
   - **Guided Assembly**: Click **`Guided Assembly`** and use **`Next →`**, **`← Prev`**, **`✓ Do Step`**, **`Skip ⏭`**, and **`↺ Restart`** to learn why every single wire and resistor is required.
4. **Power ON and Watch Live 3D Component Behaviour**:
   - Click **`⚡ CIRCUIT POWER: ON`** to boot the virtual ESP32, illuminate the 3D **Green Monitoring LED (`GPIO 2`)**, and start 40kHz ultrasonic pulses.
   - Drag the **`🎯 Move 3D Calibration Target in Front of Sensor`** slider from `400 cm` down below `150 cm` to watch the 3D target move closer, the distance reading update live, the 3D **Red Warning LED (`GPIO 19`)** light up, the **Active Buzzer (`GPIO 23`)** vibrate with 3D sound rings, and the **SX1278 LoRa Module** fire a glowing 3D RF packet to the Gateway!
5. **Run the 15-Step Hardware Demo & 10-Stop Jury Presentation**:
   - Click **`▶️ START COMPLETE HARDWARE DEMONSTRATION`** to run the automated 15-step hardware sequence (or test the 8 scenario/fault buttons: *Human Detection, Multiple Animals, Sensor Disconnection, Broken Wire, Incorrect GPIO, Low Battery, LoRa Failure, System Recovery*).
   - Click **`🎓 WILDGUARD VIRTUAL HARDWARE PRESENTATION`** for a 10-stop automated camera tour designed for hackathon judges, with **`⏸ Pause`** and **`▶ Resume`** controls at every component.
